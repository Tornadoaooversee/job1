package ru.pythonlab.ozonshifthunter.core

/** Runtime guard: UI automation is allowed only while the display is interactive and Ozon is foreground. */
enum class RuntimeGateReason { READY, SCREEN_OFF, FOREIGN_APP }

data class RuntimeGateDecision(val allowed: Boolean, val reason: RuntimeGateReason)

object RuntimeGate {
    fun evaluate(screenInteractive: Boolean, activePackage: String, isOzonPackage: (String) -> Boolean = ScreenParser.defaultPackageFilter): RuntimeGateDecision {
        if (!screenInteractive) return RuntimeGateDecision(false, RuntimeGateReason.SCREEN_OFF)
        if (!isOzonPackage(activePackage)) return RuntimeGateDecision(false, RuntimeGateReason.FOREIGN_APP)
        return RuntimeGateDecision(true, RuntimeGateReason.READY)
    }
}
