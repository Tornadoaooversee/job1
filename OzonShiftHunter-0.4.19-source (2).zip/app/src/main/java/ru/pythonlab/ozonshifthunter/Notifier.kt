package ru.pythonlab.ozonshifthunter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context

object Notifier {
    private const val CHANNEL = "shifts"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Смены Ozon Job", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun channelEnabled(context: Context): Boolean {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return false
        val channel = nm.getNotificationChannel(CHANNEL) ?: return true // будет создан до первой отправки
        return channel.importance != NotificationManager.IMPORTANCE_NONE
    }

    fun post(context: Context, title: String, text: String, dedupeId: String) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        ensureChannel(context)
        if (!nm.areNotificationsEnabled()) {
            LogStore.log(context, "NOTIFY заблокировано системой (нет разрешения на уведомления): $title — $text")
            return
        }
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val pi = launch?.let { PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .apply { if (pi != null) setContentIntent(pi) }
            .build()
        nm.notify(dedupeId.hashCode(), n)
        LogStore.log(context, "NOTIFY отправлено: $title — $text")
    }
}
