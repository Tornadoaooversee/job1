package ru.pythonlab.ozonshifthunter

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.security.MessageDigest

/** Получает системные уведомления Ozon Job. Не читает и не сохраняет их текст. */
class OzonNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        isConnectedNow = true
        super.onListenerConnected()
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_CONNECTED, true)
            .putLong(KEY_CONNECTED_AT, System.currentTimeMillis())
            .apply()
        LogStore.log(this, "NOTIFICATION_LISTENER подключён Android")
    }

    override fun onListenerDisconnected() {
        isConnectedNow = false
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_CONNECTED, false)
            .apply()
        LogStore.log(this, "NOTIFICATION_LISTENER отключён Android; фоновые сигналы временно недоступны")
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!OzonNotificationPolicy.shouldHandle(sbn.packageName, packageName, sbn.isOngoing)) return

        val now = System.currentTimeMillis()
        val identity = "${sbn.packageName}|${sbn.tag.orEmpty()}|${sbn.id}"
        val keyHash = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val previousKey = prefs.getString(KEY_LAST, null)
        val previousAt = prefs.getLong(KEY_LAST_AT, 0L)
        if (OzonNotificationPolicy.isDuplicate(previousKey, previousAt, keyHash, now)) return

        val count = prefs.getLong(KEY_COUNT, 0L) + 1L
        prefs.edit()
            .putString(KEY_LAST, keyHash)
            .putLong(KEY_LAST_AT, now)
            .putLong(KEY_COUNT, count)
            .apply()
        // Не передаём текст/заголовок Ozon в журнал или собственные уведомления.
        Notifier.post(
            this,
            "Уведомление от Ozon Job",
            "Ozon Job прислал уведомление. Открой приложение и проверь доступные смены.",
            "ozon-system-$keyHash"
        )
        LogStore.log(this, "BACKGROUND_SIGNAL получено системное уведомление Ozon Job; содержимое не сохранялось")
    }

    companion object {
        @Volatile
        var isConnectedNow: Boolean = false
            private set

        private const val PREFS = "ozon_notification_listener"
        private const val KEY_LAST = "last_notification_hash"
        private const val KEY_LAST_AT = "last_notification_at"
        private const val KEY_COUNT = "notification_count"
        private const val KEY_CONNECTED = "listener_connected"
        private const val KEY_CONNECTED_AT = "listener_connected_at"

        fun diagnosticStatus(context: android.content.Context, permissionEnabled: Boolean): String {
            val prefs = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            val count = prefs.getLong(KEY_COUNT, 0L)
            val lastAt = prefs.getLong(KEY_LAST_AT, 0L)
            val connected = isConnectedNow
            val lastKnownConnected = prefs.getBoolean(KEY_CONNECTED, false)
            val connectedAt = prefs.getLong(KEY_CONNECTED_AT, 0L)
            val permission = if (permissionEnabled) "доступ разрешён" else "доступ не разрешён"
            val connection = if (connected) "служба сейчас подключена" else if (lastKnownConnected) "сейчас не подключена (последнее сохранённое состояние было подключено)" else "сейчас не подключена / ещё не подключалась"
            val connectedTime = if (connectedAt > 0L) {
                java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(connectedAt))
            } else "нет данных"
            val last = if (lastAt > 0L) {
                java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(lastAt))
            } else "ещё не было"
            return "Уведомления Ozon: $permission; $connection\nПоследнее подключение: $connectedTime\nПолучено сигналов: $count; последнее: $last"
        }
    }
}
