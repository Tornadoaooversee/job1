package ru.pythonlab.ozonshifthunter

/**
 * Политика фонового сигнала: читаем только уведомления официального пакета Ozon Job.
 * Содержимое уведомления намеренно не анализируется и не сохраняется.
 */
object OzonNotificationPolicy {
    const val OZON_JOB_PACKAGE = "ru.ozon.hire"

    fun shouldHandle(packageName: String?, ownPackage: String, isOngoing: Boolean): Boolean {
        return packageName == OZON_JOB_PACKAGE && packageName != ownPackage && !isOngoing
    }

    /** Повтор одного системного уведомления подавляется на короткое время. */
    fun isDuplicate(previousKey: String?, previousAtMs: Long, currentKey: String, nowMs: Long): Boolean {
        return previousKey == currentKey && nowMs >= previousAtMs && nowMs - previousAtMs < DEDUPE_WINDOW_MS
    }

    const val DEDUPE_WINDOW_MS = 120_000L
}
