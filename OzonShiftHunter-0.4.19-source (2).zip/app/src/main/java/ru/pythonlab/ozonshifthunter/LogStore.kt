package ru.pythonlab.ozonshifthunter

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/**
 * Локальный журнал ShiftHunter. Запись в файл выполняется на одном фоновой потоке,
 * чтобы синхронный I/O не блокировал AccessibilityService и интерфейс Ozon Job.
 * Очередь ограничена: при диагностическом всплеске старые записи отбрасываются,
 * а Logcat продолжает получать сообщения.
 */
object LogStore {
    private const val TAG = "ShiftHunter"
    private const val FILE = "shifthunter.log"
    private const val MAX_BYTES = 1_500_000L
    private const val KEEP_BYTES = 900_000L
    private val lock = Any()
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    private val writer = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(256),
        ThreadFactory { task -> Thread(task, "ShiftHunter-LogWriter").apply { isDaemon = true } },
        ThreadPoolExecutor.DiscardOldestPolicy()
    )

    private fun file(context: Context): File {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        return File(dir, FILE)
    }

    fun path(context: Context): String = file(context).absolutePath

    fun log(context: Context, message: String) = logBatch(context, listOf(message))

    /** Одна задача и одна операция записи для целого дампа дерева. */
    fun logBatch(context: Context, messages: List<String>) {
        if (messages.isEmpty()) return
        messages.forEach { Log.i(TAG, it) }
        val app = context.applicationContext
        // Копируем список: вызывающий код может переиспользовать исходную коллекцию.
        val batch = messages.toList()
        writer.execute {
            synchronized(lock) {
                try {
                    val f = file(app)
                    if (f.length() > MAX_BYTES) trim(f)
                    val now = Date()
                    val text = buildString {
                        batch.forEach { message ->
                            append(fmt.format(now)).append(' ').append(message).append('\n')
                        }
                    }
                    f.appendText(text, Charsets.UTF_8)
                } catch (e: Exception) {
                    Log.e(TAG, "не удалось записать лог", e)
                }
            }
        }
    }

    private fun trim(f: File) {
        val bytes = f.readBytes()
        val from = (bytes.size - KEEP_BYTES).toInt().coerceAtLeast(0)
        val tail = String(bytes, from, bytes.size - from, Charsets.UTF_8)
        f.writeText("… (начало лога обрезано)\n" + tail.substringAfter('\n'), Charsets.UTF_8)
    }

    /** Дожидаемся ранее поставленных записей, но не блокируем интерфейс дольше 500 мс. */
    private fun flushBriefly() {
        val latch = CountDownLatch(1)
        try {
            writer.execute { latch.countDown() }
            latch.await(500, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
            // Диагностический журнал не должен мешать работе приложения.
        }
    }

    /** Полный журнал для экспорта в TXT. */
    fun fullText(context: Context): String {
        val latch = CountDownLatch(1)
        try {
            writer.execute { latch.countDown() }
            latch.await(3, TimeUnit.SECONDS)
        } catch (_: Exception) {
            // Продолжаем экспорт уже записанной части журнала.
        }
        return synchronized(lock) {
            try {
                val f = file(context)
                if (!f.exists()) "" else f.readText(Charsets.UTF_8)
            } catch (e: Exception) {
                "ошибка чтения лога: $e"
            }
        }
    }

    /** Хвост лога для отображения/копирования (в символах). */
    fun tail(context: Context, maxChars: Int = 100_000): String {
        flushBriefly()
        return synchronized(lock) {
            try {
                val f = file(context)
                if (!f.exists()) return@synchronized ""
                val text = f.readText(Charsets.UTF_8)
                if (text.length <= maxChars) text else "… (показан хвост)\n" + text.substring(text.length - maxChars).substringAfter('\n')
            } catch (e: Exception) {
                "ошибка чтения лога: $e"
            }
        }
    }

    fun clear(context: Context) {
        flushBriefly()
        synchronized(lock) { runCatching { file(context).delete() } }
    }
}
