package ru.pythonlab.ozonshifthunter.core

import java.time.LocalDate
import java.time.Month
import java.time.YearMonth

/*
 * Распознавание экранов Ozon Job по тексту и структуре дерева. Реальная структура дерева Ozon Job
 * НЕИЗВЕСТНА, поэтому все ключевые слова и эвристики собраны здесь и покрыты тестами на синтетических
 * деревьях. Если на устройстве что-то не распознаётся — смотреть лог ShiftHunter и править этот файл.
 */

data class CalendarDay(
    val date: LocalDate,
    val node: UiNode,
    val clickTarget: UiNode?,
    val selected: Boolean
)

data class CalendarInfo(
    val month: YearMonth,
    val days: List<CalendarDay>,
    val timeButton: UiNode?,
    /** true, если хоть у одного дня виден признак выбора (selected/checked/«выбран»). */
    val selectionObservable: Boolean
) {
    val selectedDay: CalendarDay? get() = days.firstOrNull { it.selected }
    /** Ozon Job позволяет выбрать несколько дней сразу; при этом дата для окна времени неоднозначна. */
    val selectedDays: List<CalendarDay> get() = days.filter { it.selected }
}

data class IntervalOption(
    val interval: ShiftInterval,
    val textNode: UiNode,
    val row: UiNode?,
    /** Узел, на который нужно нажать, чтобы отметить интервал. */
    val toggle: UiNode?,
    /** null — состояние галочки определить не удалось. */
    val checked: Boolean?,
    val enabled: Boolean,
    /** Приоритет, если он прямо назван в тексте/описании строки. */
    val textPriority: Priority
)

data class PickerInfo(
    val options: List<IntervalOption>,
    val bookButton: UiNode?,
    /** Интервалы в тексте, которые не являются ни 08–20, ни 20–08 (для диагностики). */
    val otherIntervals: List<String>
)

object ScreenParser {
    private val MONTHS = listOf(
        "январ" to Month.JANUARY, "феврал" to Month.FEBRUARY, "март" to Month.MARCH,
        "апрел" to Month.APRIL, "ма" to Month.MAY, "июн" to Month.JUNE, "июл" to Month.JULY,
        "август" to Month.AUGUST, "сентябр" to Month.SEPTEMBER, "октябр" to Month.OCTOBER,
        "ноябр" to Month.NOVEMBER, "декабр" to Month.DECEMBER
    )
    private const val MONTH_RE =
        "январ[ьяе]|феврал[ьяе]|март[ае]?|апрел[ьяе]|ма[йяе]|июн[ьяе]|июл[ьяе]|август[ае]?|сентябр[ьяе]|октябр[ьяе]|ноябр[ьяе]|декабр[ьяе]"

    private val MONTH_HEADER = Regex("^($MONTH_RE)(?:\\s+(\\d{4}))?(?:\\s*г\\.?)?$")
    private val DAY_WITH_MONTH = Regex("^(\\d{1,2})\\s+($MONTH_RE)(?:\\s+(\\d{4}))?")
    private val PLAIN_DAY = Regex("^(\\d{1,2})$")
    val INTERVAL_RE = Regex("(\\d{1,2})[:.](\\d{2})\\s*(?:[–—−-]|до)\\s*(\\d{1,2})[:.](\\d{2})")
    private val TIME_BUTTON = Regex("^выбрать время$")
    private val BOOK_BUTTON = Regex("^записаться(?: на смену)?$")

    private val SUCCESS = Regex("вы записаны|запись подтвержден|смена назначена|успешно записан|вы успешно записались|запись оформлена")
    // Only a post-submit acceptance message counts; the word «ОЧЕРЕДЬ» on the picker does not.
    private val WAITLIST_ACCEPTED = Regex("вы в очереди|вы добавлены в очередь|вы записаны в очередь|заявка принята в очередь|вы поставлены в очередь|поставлены в очередь|добавлены в очередь")
    private val ERROR = Regex("не удалось записат|не удалось выполнить|нет свободных мест|мест нет|смена недоступна|слот недоступен|уже занят|попробуйте позже|произошла ошибка|запись не подтвержден|заявка отклонена|запись отменена|не в очереди|не поставлен[аы]? в очередь|не добавлен[аы]? в очередь")

    private val HOT_WORDS = Regex("горящ")
    private val GREEN_WORDS = Regex("высокая вероятност")
    private val YELLOW_WORDS = Regex("низкая вероятност")

    const val SELECTED_DAY_ID = "name=selectedDay"
    private val PLAIN_SHIFT_CELLS = listOf("name=availableShift", "name=queueShift", "name=nightShift")

    /**
     * Приоритет дня по иконкам HireIcon[name=…] внутри ячейки (подтверждено логом):
     *  - ic_m_hot_filled → RED (огонёк, 100% надёжно: появляется только на горящей смене);
     *  - ic_m_sort_small_large_filled_3 → GREEN, _1/_2 → YELLOW: ГИПОТЕЗА по docs/SCREENSHOT_FINDINGS.md
     *    («три зелёные полосы», «жёлтые/оранжевые полосы»). Проверяется по логу: в CALENDAR пишется имя иконки.
     * Остальные иконки (монеты, ночь) приоритет не задают.
     */
    fun priorityFromIcons(viewIds: List<String>): Priority {
        val icons = viewIds.filter { it.startsWith("HireIcon[name=") }
        return when {
            icons.any { it.contains("ic_m_hot_filled") } -> Priority.RED
            icons.any { it.contains("ic_m_sort_small_large_filled_3") } -> Priority.GREEN
            icons.any { it.contains("ic_m_sort_small_large_filled_1") || it.contains("ic_m_sort_small_large_filled_2") } -> Priority.YELLOW
            else -> Priority.UNKNOWN
        }
    }

    /** Имена иконок ячейки для лога (чтобы по логу сверять гипотезу цвет ↔ иконка). */
    fun iconNames(viewIds: List<String>): List<String> =
        viewIds.filter { it.startsWith("HireIcon[name=") }.map { it.removePrefix("HireIcon[name=").removeSuffix("]").removePrefix("ic_m_") }

    /**
     * «Обычная» (белая) смена: доступная ячейка (availableShift/queueShift/nightShift) без индикаторов.
     * Ночная иконка маркирует тип смены, а не приоритет, поэтому не считается индикатором.
     */
    fun isPlainShiftCell(cellViewId: String, subtreeViewIds: List<String>): Boolean {
        if (PLAIN_SHIFT_CELLS.none { cellViewId.contains(it) }) return false
        return subtreeViewIds.none { it.startsWith("HireIcon[name=") && !it.contains("ic_m_night_filled") }
    }

    fun monthFromWord(word: String): Month? {
        val w = normalize(word)
        return MONTHS.firstOrNull { w.startsWith(it.first) && (it.first != "ма" || w.length <= 3) }?.second
    }

    /** Приоритет, явно названный текстом. UNKNOWN — не назван. */
    fun priorityFromText(vararg texts: String): Priority {
        val joined = normalize(texts.joinToString(" "))
        return when {
            HOT_WORDS.containsMatchIn(joined) -> Priority.RED
            GREEN_WORDS.containsMatchIn(joined) -> Priority.GREEN
            YELLOW_WORDS.containsMatchIn(joined) -> Priority.YELLOW
            else -> Priority.UNKNOWN
        }
    }

    fun parseInterval(text: String): ShiftInterval? {
        val m = INTERVAL_RE.find(text) ?: return null
        val (a, b, c, d) = m.destructured
        return ShiftInterval.fromTimes(a.toInt(), b.toInt(), c.toInt(), d.toInt())
    }

    /** Структурный тип экрана. Результат записи определяется отдельно, см. [detectResult]. */
    fun classify(snap: ScreenSnapshot, packageFilter: (String) -> Boolean = defaultPackageFilter): ScreenType {
        if (!packageFilter(snap.packageName)) return ScreenType.NOT_OZON
        // Окно «Записи» после отправки («В очереди», «Отменить», «Записаться ещё») содержит интервал
        // «Омск РФЦ, 20:00–8:00», но это результат, а не выбор времени (по логу оно принималось за TIME_PICKER).
        if (snap.nodes.any { normalize(it.label) == "записаться еще" }) return ScreenType.UNKNOWN
        if (snap.nodes.any { it.label.isNotEmpty() && INTERVAL_RE.containsMatchIn(it.label) }) return ScreenType.TIME_PICKER
        if (parseCalendar(snap, LocalDate.of(2000, 1, 1)) != null) return ScreenType.CALENDAR
        return ScreenType.UNKNOWN
    }

    /**
     * Результат нажатия «Записаться». Вызывается ТОЛЬКО после нашего клика: слова вроде
     * «нет свободных мест» могут встречаться и на обычных экранах.
     */
    fun detectResult(snap: ScreenSnapshot, date: LocalDate? = null, interval: ShiftInterval? = null): BookingResult? {
        if (snap.truncated || !defaultPackageFilter(snap.packageName)) return null // чужое приложение и неполный снимок не подтверждают результат
        val labels = snap.allLabels().map { normalize(it) }
        // Ошибка имеет приоритет: экран может показывать старое подтверждение и новую ошибку.
        if (labels.any { ERROR.containsMatchIn(it) }) return BookingResult.ERROR
        val negated = Regex("не\\s+записан|не\\s+подтвержден|отменен|отменена|не\\s+удалось|не\\s+в\\s+очереди|не\\s+поставлен|не\\s+добавлен")
        if (labels.any { SUCCESS.containsMatchIn(it) && !negated.containsMatchIn(it) }) return BookingResult.SUCCESS
        if (labels.any { WAITLIST_ACCEPTED.containsMatchIn(it) && !negated.containsMatchIn(it) }) return BookingResult.WAITLISTED
        // Реальное окно результата (лог 14.11): «21 ноября / Записи / В очереди / Отменить / Омск РФЦ, 20:00–8:00 /
        // Записаться ещё». Засчитываем, только если дата и интервал в окне совпадают с нашей попыткой.
        if (labels.any { it == "в очереди" } && labels.any { it == "записаться еще" || it == "отменить" } &&
            resultSheetMatches(labels, date, interval)
        ) return BookingResult.WAITLISTED
        return null
    }

    private fun resultSheetMatches(labels: List<String>, date: LocalDate?, interval: ShiftInterval?): Boolean {
        if (date != null) {
            val ok = labels.any { l ->
                val m = DAY_WITH_MONTH.find(l)
                m != null && m.groupValues[1].toInt() == date.dayOfMonth && monthFromWord(m.groupValues[2]) == date.month
            }
            if (!ok) return false
        }
        if (interval != null && labels.none { parseInterval(it) == interval }) return false
        return true
    }

    val OZON_JOB_PACKAGE = "ru.ozon.hire"
    val defaultPackageFilter: (String) -> Boolean = { it == OZON_JOB_PACKAGE }

    // ---------------------------------------------------------------- календарь

    fun parseCalendar(snap: ScreenSnapshot, today: LocalDate): CalendarInfo? {
        val month = detectMonth(snap, today) ?: return null
        val ym = month

        // 1. Самый надёжный вариант: contentDescription вида «12 ноября».
        val byDesc = ArrayList<CalendarDay>()
        for (n in snap.nodes) {
            val d = normalize(n.desc.ifEmpty { n.text })
            val m = DAY_WITH_MONTH.find(d) ?: continue
            val mm = monthFromWord(m.groupValues[2]) ?: continue
            val day = m.groupValues[1].toInt()
            val year = m.groupValues[3].takeIf { it.isNotEmpty() }?.toInt() ?: ym.year
            val date = runCatching { LocalDate.of(year, mm, day) }.getOrNull() ?: continue
            if (YearMonth.from(date) != ym) continue // соседние месяцы
            byDesc += makeDay(snap, date, n)
        }
        val days = if (byDesc.map { it.date }.distinct().size >= 20) {
            byDesc.distinctBy { it.date }
        } else {
            daysFromPlainNumbers(snap, ym)
        }
        if (days.size < 20) return null

        val button = snap.nodes.firstOrNull { TIME_BUTTON.matches(normalize(it.label)) }
        return CalendarInfo(ym, days, button, days.any { it.selected })
    }

    private fun makeDay(snap: ScreenSnapshot, date: LocalDate, n: UiNode): CalendarDay {
        val target = snap.clickTarget(n)
        // Признак выбора ищем только в самой ячейке: от узла с числом до кликабельной ячейки включительно.
        val chain = if (target == null) listOf(n)
        else snap.ancestorsAndSelf(n).takeWhile { it.index != target.parent }.toList()
        // Реальный Ozon Job помечает выбранный день не флагом selected, а именем контейнера
        // HireContainer[name=selectedDay] (подтверждено логом 14.11.2026).
        val selected = chain.any {
            it.selected || (it.checked && it.checkable) || normalize(it.desc).contains("выбран") ||
                it.viewId.contains(SELECTED_DAY_ID)
        }
        return CalendarDay(date, n, target, selected)
    }

    private fun daysFromPlainNumbers(snap: ScreenSnapshot, ym: YearMonth): List<CalendarDay> {
        val cands = snap.nodes.filter { n ->
            val t = n.text.trim()
            PLAIN_DAY.matches(t) && t.toInt() in 1..31 && !n.bounds.isEmpty
        }
        if (cands.size < 20) return emptyList()
        val med = cands.map { it.bounds.height }.sorted()[cands.size / 2].coerceAtLeast(1)
        // Сортировка по рядам (кластеризация по top), затем по left.
        val byTop = cands.sortedBy { it.bounds.top }
        val rows = ArrayList<MutableList<UiNode>>()
        for (n in byTop) {
            val last = rows.lastOrNull()
            if (last != null && n.bounds.top - last.first().bounds.top <= med / 2) last += n else rows += mutableListOf(n)
        }
        val ordered = rows.flatMap { r -> r.sortedBy { it.bounds.left } }

        val out = ArrayList<CalendarDay>()
        var pos = 0
        for (d in 1..ym.lengthOfMonth()) {
            var found = -1
            for (i in pos until ordered.size) {
                if (ordered[i].text.trim().toInt() == d) { found = i; break }
            }
            if (found < 0) break // дальше последовательность не продолжается
            out += makeDay(snap, ym.atDay(d), ordered[found])
            pos = found + 1
        }
        return out
    }

    private fun detectMonth(snap: ScreenSnapshot, today: LocalDate): YearMonth? {
        for (n in snap.nodes) {
            for (raw in listOf(n.text, n.desc)) {
                if (raw.isBlank()) continue
                val m = MONTH_HEADER.find(normalize(raw)) ?: continue
                val month = monthFromWord(m.groupValues[1]) ?: continue
                val year = m.groupValues[2].takeIf { it.isNotEmpty() }?.toInt() ?: inferYear(month, today)
                return YearMonth.of(year, month)
            }
        }
        // Заголовка нет — пробуем взять месяц из «12 ноября».
        for (n in snap.nodes) {
            val m = DAY_WITH_MONTH.find(normalize(n.desc.ifEmpty { n.text })) ?: continue
            val month = monthFromWord(m.groupValues[2]) ?: continue
            val year = m.groupValues[3].takeIf { it.isNotEmpty() }?.toInt() ?: inferYear(month, today)
            return YearMonth.of(year, month)
        }
        return null
    }

    private fun inferYear(month: Month, today: LocalDate): Int {
        val diff = month.value - today.monthValue
        return when {
            diff < -6 -> today.year + 1
            diff > 6 -> today.year - 1
            else -> today.year
        }
    }

    // ---------------------------------------------------------------- выбор времени

    fun parsePicker(snap: ScreenSnapshot): PickerInfo? {
        val textNodes = snap.nodes.filter { it.label.isNotEmpty() && INTERVAL_RE.containsMatchIn(it.label) }
        if (textNodes.isEmpty()) return null
        val options = ArrayList<IntervalOption>()
        val other = ArrayList<String>()
        for (t in textNodes) {
            val interval = parseInterval(t.label)
            if (interval == null) { other += t.label; continue }
            // Строка — самый высокий предок, внутри которого только один интервал и немного узлов.
            var row: UiNode? = null
            for (a in snap.ancestorsAndSelf(t)) {
                val sub = snap.descendants(a.index) + a
                val intervalsInside = sub.count { it.label.isNotEmpty() && INTERVAL_RE.containsMatchIn(it.label) }
                if (intervalsInside != 1 || sub.size > 15) break
                row = a
            }
            val scope = if (row != null) snap.descendants(row.index) + row else listOf(t)
            val toggleNode = scope.firstOrNull { it.isToggleLike }
            val checked: Boolean? = when {
                toggleNode != null -> toggleNode.checked
                row != null && (row.selected || row.checked) -> true
                else -> null
            }
            val clickable = toggleNode?.let { snap.clickTarget(it) ?: it } ?: snap.clickTarget(t)
            options += IntervalOption(
                interval = interval,
                textNode = t,
                row = row,
                toggle = clickable,
                checked = checked,
                enabled = clickable?.enabled ?: t.enabled,
                textPriority = priorityFromText(*scope.map { it.label }.toTypedArray())
            )
        }
        val book = snap.nodes.firstOrNull { BOOK_BUTTON.matches(normalize(it.label)) }
        return PickerInfo(options.distinctBy { it.interval }, book, other)
    }

    /** Кнопка «Записаться» → узел, на который реально нужно нажать. */
    fun bookClickTarget(snap: ScreenSnapshot, p: PickerInfo): UiNode? = p.bookButton?.let { snap.clickTarget(it) ?: it }

    // ---------------------------------------------------------------- контекст

    /**
     * Видны ли на экране выбранные склад и операция. Пустой склад в настройках считается подходящим.
     * Операция сопоставляется строго: «Подбор» не считается видимым, если на экране «Подбор возвратов».
     */
    fun contextConfirmed(snap: ScreenSnapshot, s: HunterSettings): Boolean {
        // All three selectors are mandatory. An empty value must never act as a wildcard:
        // otherwise a forgotten region/warehouse could silently authorize clicks.
        if (s.region.isBlank() || s.warehouse.isBlank() || s.operation.isBlank()) return false
        val labels = snap.allLabels().map { normalize(it) }
        fun seen(v: String) = labels.any { it.contains(normalize(v)) }
        // Region may be shown separately or as part of the warehouse label.
        // Merely storing it in settings is not proof that Ozon selected it.
        // Склад — только точное совпадение подписи: «Грозный Хаб» не должен пройти на экране «Грозный Хаб КГТ».
        return seen(s.region) && warehouseExact(labels, s.warehouse) && operationVisible(labels, s.operation)
    }

    private fun warehouseExact(labels: List<String>, warehouse: String): Boolean {
        val w = normalize(warehouse)
        return w.isNotEmpty() && labels.any { it == w }
    }

    /**
     * Календарь Ozon Job показывает склад и операцию, но НЕ регион (лог 14.11). Поэтому регион подтверждается
     * на пути к календарю: на экране списка складов региона рядом со складом из настроек виден текст региона
     * (заголовок или адрес). Эта функция — «склад из настроек виден, и рядом есть текст региона».
     */
    fun regionWarehousePairVisible(snap: ScreenSnapshot, s: HunterSettings): Boolean {
        if (s.region.isBlank() || s.warehouse.isBlank()) return false
        val labels = snap.allLabels().map { normalize(it) }
        val w = normalize(s.warehouse)
        val r = normalize(s.region)
        return labels.any { it == w } && labels.any { it != w && it.contains(r) }
    }

    /** Склад (точно) и операция видны; регион на этом экране не требуется (его подтверждает [regionWarehousePairVisible]). */
    fun contextConfirmedWithoutRegion(snap: ScreenSnapshot, s: HunterSettings): Boolean {
        if (s.region.isBlank() || s.warehouse.isBlank() || s.operation.isBlank()) return false
        val labels = snap.allLabels().map { normalize(it) }
        return warehouseExact(labels, s.warehouse) && operationVisible(labels, s.operation)
    }

    // ---------------------------------------------------------------- список операций («ДОСТУПНЫЕ»)

    /** Цена карточки операции: «≈6 848 ₽» (без «/ 12 ч» — так отличаются карточки складов и окно времени). */
    private val OPERATION_PRICE = Regex("^≈\\s*[\\d\\s\\u00A0\\u202F]+₽$")
    private val DATE_CHIP = Regex("^(\\d{1,2}\\.\\d{2}|сегодня|завтра|\\+\\d+ (?:день|дня|дней))$")
    private val NOT_OPERATION_TITLES = setOf("тариф", "даты:", "даты", "доступные", "недоступные", "обучение", "нет мест")

    private fun isOperationTitle(raw: String): Boolean {
        val t = normalize(raw)
        if (t.length !in 3..60) return false
        if (t in NOT_OPERATION_TITLES) return false
        if (OPERATION_PRICE.matches(raw.trim()) || DATE_CHIP.matches(t)) return false
        if (t.any { it.isDigit() }) return false
        return t.count { it.isLetter() } >= 3
    }

    /**
     * Названия операций с экрана списка («ДОСТУПНЫЕ»: «Размещение», «Подбор», …, «Подбор возвратов»).
     * Карточка = заголовок + цена «≈N ₽» + кнопка «Тариф» + даты. Название берётся рядом с ценой в порядке обхода дерева
     * (сначала предыдущая подпись, затем следующая). Структура дерева этого экрана в логах пока не снималась —
     * разбор построен по скриншотам и проверяется тестами на синтетическом дереве.
     */
    fun operationTitles(snap: ScreenSnapshot): List<String> {
        val labels = snap.nodes.map { it.label.trim() }.filter { it.isNotEmpty() }
        val out = LinkedHashSet<String>()
        for ((i, l) in labels.withIndex()) {
            if (!OPERATION_PRICE.matches(l)) continue
            val prev = labels.getOrNull(i - 1)
            val next = labels.getOrNull(i + 1)
            val title = when {
                prev != null && isOperationTitle(prev) -> prev
                next != null && isOperationTitle(next) -> next
                else -> null
            }
            if (title != null) out += title
        }
        return out.toList()
    }

    /** Что из «регион / склад / операция» не подтверждено экраном (для диагностики в логе). */
    fun contextMissing(snap: ScreenSnapshot, s: HunterSettings): List<String> {
        val labels = snap.allLabels().map { normalize(it) }
        fun seen(v: String) = v.isNotBlank() && labels.any { it.contains(normalize(v)) }
        val out = ArrayList<String>()
        if (!seen(s.region)) out += "регион"
        if (!warehouseExact(labels, s.warehouse)) out += "склад (нужно точное совпадение названия)"
        if (s.operation.isBlank() || !operationVisible(labels, s.operation)) out += "операция"
        return out
    }

    private fun operationVisible(labels: List<String>, operation: String): Boolean {
        val op = normalize(operation)
        // Более длинные известные операции, в названии которых содержится выбранная («Подбор» ⊂ «Подбор возвратов»).
        val longer = KnownOperations.ALL.map { normalize(it) }.filter { it != op && it.contains(op) }
        return labels.any { l ->
            l == op || (l.contains(op) && longer.none { l.contains(it) })
        }
    }
}
