package ru.pythonlab.ozonshifthunter

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.*
import ru.pythonlab.ozonshifthunter.core.KnownOperations
import java.time.DayOfWeek

class MainActivity : Activity() {
    private var pendingLogExport: String = ""
    private val exportLogRequestCode = 7412
    private val prefs by lazy { getSharedPreferences("hunter_settings", MODE_PRIVATE) }
    private val operations: List<String> get() = (KnownOperations.ALL + CatalogCapture.get(this, CatalogCapture.OPERATIONS)).distinct().sorted()
    private val regions: List<String> get() = (regionDefaults + CatalogCapture.get(this, CatalogCapture.REGIONS)).distinct().sorted()
    private val regionDefaults = listOf(
        "Ленинградская Область", "Краснодарский Край", "Адыгея Республика",
        "Ростовская Область", "Челябинская Область", "Нижегородская Область",
        "Свердловская Область", "Татарстан Республика", "Пермский Край",
        "Красноярский Край", "Воронежская Область", "Башкортостан Республика",
        "Новосибирская Область", "Тюменская Область", "Самарская Область",
        "Ханты-Мансийский Автономный округ - Югра", "Ставропольский Край",
        "Хабаровский Край", "Смоленская Область", "Калининградская Область",
        "Волгоградская Область", "Вологодская Область", "Приморский Край",
        "Саратовская Область", "Алтайский Край", "Пензенская Область",
        "Кемеровская область - Кузбасс", "Тверская Область", "Ярославская Область",
        "Иркутская Область", "Бурятия Республика", "Оренбургская Область",
        "Тульская Область", "Удмуртская Республика", "Республика Коми",
        "Ивановская Область", "Чувашская Республика - Чувашия", "Кировская Область",
        "Амурская Область", "Республика Мордовия", "Ямало-Ненецкий Автономный округ",
        "Брянская Область", "Курская Область", "Рязанская Область",
        "Республика Карелия", "Калужская Область", "Псковская Область",
        "Астраханская Область", "Белгородская Область", "Ульяновская Область",
        "Владимирская Область", "Липецкая Область", "Новгородская Область",
        "Орловская Область", "Республика Марий Эл", "Томская Область",
        "Дагестан Республика", "Хакасия Республика", "Забайкальский Край",
        "Архангельская Область", "Мурманская Область", "Тамбовская Область",
        "Чеченская Республика", "Костромская Область", "Республика Северная Осетия - Алания"
    )
    private val weekdays = listOf(
        DayOfWeek.MONDAY to "Понедельник", DayOfWeek.TUESDAY to "Вторник",
        DayOfWeek.WEDNESDAY to "Среда", DayOfWeek.THURSDAY to "Четверг",
        DayOfWeek.FRIDAY to "Пятница", DayOfWeek.SATURDAY to "Суббота",
        DayOfWeek.SUNDAY to "Воскресенье"
    )
    private val weekdayModes = mutableMapOf<DayOfWeek, String>()
    private var statusView: TextView? = null
    private var notificationStatusView: TextView? = null
    private var readinessView: TextView? = null
    private var logPreview: TextView? = null
    private var serviceCard: LinearLayout? = null
    private var regionInput: AutoCompleteTextView? = null
    private var warehouseInput: AutoCompleteTextView? = null
    private var operationSpinner: Spinner? = null
    private var catalogSummary: TextView? = null

    private val bg = Color.rgb(10, 15, 28)
    private val surface = Color.rgb(20, 28, 46)
    private val surface2 = Color.rgb(27, 37, 59)
    private val stroke = Color.rgb(43, 57, 83)
    private val white = Color.rgb(242, 246, 255)
    private val muted = Color.rgb(151, 165, 190)
    private val blue = Color.rgb(83, 145, 255)
    private val green = Color.rgb(62, 203, 145)
    private val amber = Color.rgb(255, 190, 75)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        Notifier.ensureChannel(this)
        buildScreen()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCatalogSuggestions()
        refreshStatus()
    }

    private fun refreshCatalogSuggestions() {
        regionInput?.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, regions))
        warehouseInput?.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, CatalogCapture.get(this, CatalogCapture.WAREHOUSES)))
        val options = operations.ifEmpty { KnownOperations.ALL }
        operationSpinner?.let { spinner ->
            val current = spinner.selectedItem?.toString() ?: prefs.getString("operation", "").orEmpty()
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            spinner.setSelection(options.indexOf(current).coerceAtLeast(0))
        }
        CatalogCapture.counts(this).let { c ->
            catalogSummary?.text = "Собрано из видимых экранов Ozon Job: регионы — ${c.regions}, склады — ${c.warehouses}, операции — ${c.operations}. Подсказки сохраняются только на этом телефоне."
        }
    }

    private fun serviceEnabled(): Boolean {
        val am = getSystemService(AccessibilityManager::class.java) ?: return false
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun openOzonJob() {
        val launch = packageManager.getLaunchIntentForPackage(OzonNotificationPolicy.OZON_JOB_PACKAGE)
        if (launch == null) {
            Toast.makeText(this, "Ozon Job не найден. Установи официальное приложение.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(launch)
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть Ozon Job", Toast.LENGTH_LONG).show()
        }
    }

    private fun notificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val expected = ComponentName(this, OzonNotificationListener::class.java).flattenToString()
        return enabled.split(":").any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshStatus() {
        val s = SettingsStore.load(this)
        val saved = prefs.contains("operation")
        val enabled = serviceEnabled()
        val notificationsEnabled = notificationListenerEnabled()
        val ozonInstalled = packageManager.getLaunchIntentForPackage(OzonNotificationPolicy.OZON_JOB_PACKAGE) != null
        val powerManager = getSystemService(android.os.PowerManager::class.java)
        val batteryExempt = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || powerManager?.isIgnoringBatteryOptimizations(packageName) == true
        val postPermission = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val appNotifications = getSystemService(android.app.NotificationManager::class.java)?.areNotificationsEnabled() == true
        val channelEnabled = Notifier.channelEnabled(this)
        readinessView?.text = buildString {
            append(if (ozonInstalled) "✓ Ozon Job установлен" else "✕ Ozon Job не установлен")
            append("\n").append(if (notificationsEnabled) "✓ Доступ к уведомлениям Ozon Job" else "✕ Нет доступа к уведомлениям Ozon Job")
            append("\n").append(if (enabled) "✓ Accessibility включён" else "✕ Accessibility выключен")
            append("\n").append(if (postPermission && appNotifications && channelEnabled) "✓ Уведомления Hunter разрешены" else "✕ Уведомления Hunter заблокированы или ограничены")
            append("\n").append(if (batteryExempt) "✓ Оптимизация батареи не ограничивает Hunter" else "! Android может ограничивать работу Hunter в фоне")
            append("\n\n").append(if (enabled && notificationsEnabled && ozonInstalled && postPermission && appNotifications && channelEnabled) "Основные разрешения готовы. Это не гарантирует обнаружение каждой смены." else "Включи недостающие разрешения ниже. После изменения вернись сюда и проверь статус.")
        }
        notificationStatusView?.text = OzonNotificationListener.diagnosticStatus(this, notificationsEnabled)
        statusView?.text = buildString {
            append(if (enabled) "Служба специальных возможностей включена" else "Служба выключена — включи её в настройках Android")
            append("\nOzon Job: ").append(if (ozonInstalled) "установлен" else "не найден")
            append("\nОграничения батареи: ").append(if (batteryExempt) "нет системной оптимизации для Hunter" else "оптимизация включена — Android может ограничивать фоновые процессы")
            append("\nФоновый сигнал Ozon: ").append(if (notificationsEnabled) "доступ к уведомлениям включён" else "доступ к уведомлениям не включён")
            if (enabled) append("\nСлужба может оставаться активной при сворачивании Hunter.")
            append("\nПоиск и безопасные действия доступны только когда Ozon Job находится на переднем плане и экран включён. При другом приложении или выключенном экране — пауза.")
            append("\n").append(if (s.dryRun) "Режим наблюдения активен: приложение ничего не нажимает" else "Нажатия разрешены — проверь правила перед запуском")
            if (!saved) append("\nНастройки ещё не сохранены")
            else {
                if (s.region.isBlank()) append("\nНе указан регион")
                if (s.warehouse.isBlank()) append("\nНе указан склад")
                if (s.operation !in operations) append("\nСохранённая операция не найдена — выбери её заново")
            }
        }
        serviceCard?.background = rounded(if (enabled) Color.rgb(17, 54, 53) else Color.rgb(64, 42, 31), 18, if (enabled) Color.rgb(38, 105, 89) else Color.rgb(123, 83, 44))
        val tail = LogStore.tail(this, 6000).lines().takeLast(25).joinToString("\n")
        logPreview?.text = if (tail.isBlank()) "Журнал пока пуст" else tail
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(page)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandMark = TextView(this).apply {
            text = "OH"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(blue, 16)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brandText.addView(text("OZON SHIFT", 12f, blue, true))
        brandText.addView(text("HUNTER", 24f, white, true))
        top.addView(brandMark)
        top.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(pill("v0.4.17", surface2, muted))
        page.addView(top)
        page.addView(space(18))

        val hero = card(22)
        hero.addView(text("Твой помощник\nдля поиска смен", 25f, white, true))
        hero.addView(space(8))
        hero.addView(text("Настрой параметры один раз — ShiftHunter будет отслеживать смены, когда Ozon Job открыт на экране.", 14f, muted))
        hero.addView(space(16))
        val heroBottom = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        heroBottom.addView(pill("●  МОНИТОРИНГ СМЕН", Color.rgb(22, 55, 75), Color.rgb(120, 190, 255)))
        heroBottom.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        heroBottom.addView(text("Умный поиск", 12f, muted, true))
        hero.addView(heroBottom)
        page.addView(hero)
        page.addView(space(8))
        page.addView(smallButton("Открыть Ozon Job  →") { openOzonJob() }, matchWrap(50))
        page.addView(space(14))

        sectionHeader(page, "01", "Параметры поиска", "Где и какую смену искать")
        val searchCard = card()
        val region = regionField(searchCard).also { regionInput = it }
        val warehouse = field(searchCard, "СКЛАД", "Например, Омск РФЦ", "warehouse", CatalogCapture.get(this, CatalogCapture.WAREHOUSES)).also { warehouseInput = it }
        searchCard.addView(text("ОПЕРАЦИЯ", 11f, muted, true))
        val operationOptions = operations.ifEmpty { KnownOperations.ALL }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, operationOptions).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            background = rounded(surface2, 14, stroke)
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        val savedOperation = prefs.getString("operation", operationOptions.first())
        spinner.setSelection(operationOptions.indexOf(savedOperation).coerceAtLeast(0))
        operationSpinner = spinner
        searchCard.addView(spinner, matchWrap(52))
        page.addView(searchCard)
        page.addView(space(8))
        val catalogCard = card()
        val catalogCounts = CatalogCapture.counts(this)
        catalogCard.addView(text("ЛОКАЛЬНЫЙ СПРАВОЧНИК", 11f, blue, true))
        catalogCard.addView(space(5))
        catalogSummary = text("Собрано из видимых экранов Ozon Job: регионы — ${catalogCounts.regions}, склады — ${catalogCounts.warehouses}, операции — ${catalogCounts.operations}. Подсказки сохраняются только на этом телефоне.", 12f, muted)
        catalogCard.addView(catalogSummary)
        catalogCard.addView(space(8))
        catalogCard.addView(smallButton("Очистить собранные подсказки", subtle = true) {
            CatalogCapture.clear(this@MainActivity)
            Toast.makeText(this@MainActivity, "Локальный справочник очищен", Toast.LENGTH_SHORT).show()
            buildScreen()
        })
        page.addView(catalogCard)
        page.addView(space(14))

        sectionHeader(page, "02", "Время смены", "Выбери подходящие интервалы")
        val timeCard = card()
        val day = toggleRow(timeCard, "☀", "Дневная смена", "08:00 — 20:00", "day", true, amber)
        val night = toggleRow(timeCard, "☾", "Ночная смена", "20:00 — 08:00", "night", false, blue)
        timeCard.addView(text("Можно выбрать один или оба интервала.", 12f, muted))
        page.addView(timeCard)
        page.addView(space(14))

        sectionHeader(page, "03", "Правила по дням", "Режим обработки для каждого дня недели")
        val weekCard = card()
        weekCard.addView(text("Автозапись работает только при включённом общем разрешении и режиме «Автозапись» для выбранного дня.", 12f, muted))
        weekCard.addView(space(10))
        weekdays.forEachIndexed { index, (weekday, dayName) ->
            val savedMode = prefs.getString(BookingPolicy.keyFor(weekday), BookingPolicy.MODE_NOTIFY) ?: BookingPolicy.MODE_NOTIFY
            weekdayModes[weekday] = savedMode
            weekCard.addView(weekdayRow(weekday, dayName, savedMode))
            if (index != weekdays.lastIndex) weekCard.addView(divider())
        }
        page.addView(weekCard)
        page.addView(space(14))

        sectionHeader(page, "04", "Автоматизация", "Контролируй действия приложения")
        val automation = card()
        val auto = switchRow(automation, "Разрешить автозапись", "Только для дней с соответствующим правилом", "auto", false)
        val hot = switchRow(automation, "Только горящие смены", "Остальные подходящие смены будут приходить как уведомления", "hot", false)
        automation.addView(divider())
        val dryRun = switchRow(automation, "Режим наблюдения", "Безопасный режим: анализирует экран, но не нажимает кнопки", "dry_run", true)
        automation.addView(space(8))
        val safety = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(20, 45, 66), 14)
        }
        safety.addView(text("ⓘ", 18f, Color.rgb(117, 190, 255), true))
        safety.addView(text(" Рекомендуем оставить режим наблюдения включённым, пока в журнале не подтверждено корректное распознавание экранов.", 12f, Color.rgb(184, 211, 238)))
        automation.addView(safety)
        page.addView(automation)
        page.addView(space(14))

        sectionHeader(page, "05", "Приоритет смен", "Какие предложения важнее")
        val priority = card()
        priority.addView(priorityRow("🔴", "Горящая смена", "Высший приоритет", Color.rgb(255, 111, 111)))
        priority.addView(divider())
        priority.addView(priorityRow("🟢", "Высокая вероятность", "Второй приоритет", green))
        priority.addView(divider())
        priority.addView(priorityRow("🟡", "Низкий приоритет", "Игнорируется", amber))
        page.addView(priority)
        page.addView(space(14))

        sectionHeader(page, "06", "Готовность системы", "Все необходимые разрешения в одном месте")
        val readinessCard = card()
        readinessView = text("Проверяем разрешения…", 13f, white).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(11, 17, 30), 12, stroke)
        }
        readinessCard.addView(readinessView, matchWrap(160))
        readinessCard.addView(space(10))
        readinessCard.addView(smallButton("Включить Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        readinessCard.addView(space(6))
        readinessCard.addView(smallButton("Доступ к уведомлениям Ozon Job") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        readinessCard.addView(space(6))
        readinessCard.addView(smallButton("Уведомления самого Hunter") {
            try {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName") })
            }
        })
        readinessCard.addView(space(6))
        readinessCard.addView(smallButton("Ограничения батареи") {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName") }) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        page.addView(readinessCard)
        page.addView(space(12))

        sectionHeader(page, "07", "Состояние службы", "Текущая работа и ограничения Android")
        serviceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(Color.rgb(17, 54, 53), 18, Color.rgb(38, 105, 89))
        }
        serviceCard!!.addView(text("●  СТАТУС МОНИТОРИНГА", 11f, green, true))
        statusView = text("Проверяем состояние…", 13f, white)
        serviceCard!!.addView(space(8))
        serviceCard!!.addView(statusView)
        page.addView(serviceCard)
        page.addView(space(12))

        val save = Button(this).apply {
            text = "СОХРАНИТЬ НАСТРОЙКИ  →"
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(blue, 17)
            elevation = dp(3).toFloat()
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                val selectedRegion = region.text.toString().trim()
                val selectedWarehouse = warehouse.text.toString().trim()
                if (selectedRegion.isBlank()) {
                    Toast.makeText(this@MainActivity, "Укажи регион", Toast.LENGTH_SHORT).show()
                    region.requestFocus()
                    return@setOnClickListener
                }
                if (selectedWarehouse.isBlank()) {
                    Toast.makeText(this@MainActivity, "Укажи склад", Toast.LENGTH_SHORT).show()
                    warehouse.requestFocus()
                    return@setOnClickListener
                }
                if (!day.isChecked && !night.isChecked) {
                    Toast.makeText(this@MainActivity, "Выбери хотя бы один интервал времени", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val editor = prefs.edit()
                    .putString("region", selectedRegion)
                    .putString("warehouse", selectedWarehouse)
                    .putString("operation", spinner.selectedItem.toString())
                    .putBoolean("day", day.isChecked)
                    .putBoolean("night", night.isChecked)
                    .putBoolean("auto", auto.isChecked)
                    .putBoolean("hot", hot.isChecked)
                    .putBoolean("dry_run", dryRun.isChecked)
                weekdayModes.forEach { (weekday, mode) -> editor.putString(BookingPolicy.keyFor(weekday), mode) }
                editor.apply()
                Toast.makeText(this@MainActivity, "Настройки сохранены", Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        }
        page.addView(save, matchWrap(58))
        page.addView(space(10))

        val access = secondaryButton("⚙  Настройки службы Android") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        page.addView(access, matchWrap(50))
        page.addView(space(8))
        page.addView(secondaryButton("🔋  Настройки батареи ShiftHunter") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            } catch (_: Exception) {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                catch (_: Exception) { Toast.makeText(this, "Открой настройки батареи Android вручную", Toast.LENGTH_LONG).show() }
            }
        }, matchWrap(50))
        page.addView(space(18))

        sectionHeader(page, "08", "Фоновый сигнал Ozon Job", "Дополнительные уведомления, когда Ozon Job свёрнут")
        val backgroundCard = card()
        backgroundCard.addView(text("Этот канал замечает системные уведомления от Ozon Job, даже если приложение свёрнуто. Он не сканирует календарь и не гарантирует, что Ozon отправит уведомление о каждой новой смене. Текст уведомлений не читается и не сохраняется.", 12f, muted))
        backgroundCard.addView(space(10))
        notificationStatusView = text("Проверка доступа к уведомлениям…", 12f, white).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(11, 17, 30), 12, stroke)
        }
        backgroundCard.addView(notificationStatusView, matchWrap(64))
        backgroundCard.addView(space(10))
        backgroundCard.addView(smallButton("Разрешить уведомления Ozon Job") {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this@MainActivity, "Открой настройки специальных доступов вручную", Toast.LENGTH_LONG).show()
            }
        })
        backgroundCard.addView(space(6))
        backgroundCard.addView(text("После возврата сюда статус обновится автоматически. Разрешение можно отключить в любой момент в настройках Android.", 11f, muted))
        page.addView(backgroundCard)
        page.addView(space(14))

        sectionHeader(page, "09", "Журнал ShiftHunter", "Диагностика и история работы")
        val logs = card()
        logs.addView(text("Если приложение что-то не распознаёт, открой Ozon Job, перейди к календарю и окну выбора времени, затем отправь журнал для диагностики.", 12f, muted))
        logs.addView(space(10))
        logPreview = TextView(this).apply {
            text = "Загрузка журнала…"
            textSize = 11f
            setTextColor(Color.rgb(184, 198, 221))
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(11, 17, 30), 12, stroke)
        }
        logs.addView(logPreview, matchWrap(140))
        logs.addView(space(10))
        val logActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        logActions.addView(smallButton("Обновить") { refreshStatus() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        logActions.addView(smallButton("Отправить") {
            val log = LogStore.tail(this@MainActivity)
            if (log.isBlank()) Toast.makeText(this@MainActivity, "Лог пуст", Toast.LENGTH_SHORT).show()
            else {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "ShiftHunter log")
                    putExtra(Intent.EXTRA_TEXT, log)
                }
                startActivity(Intent.createChooser(send, "Отправить лог"))
            }
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        logs.addView(logActions)
        logs.addView(space(8))
        logs.addView(smallButton("Скачать журнал (.txt)") {
            val content = LogStore.fullText(this@MainActivity)
            if (content.isBlank()) {
                Toast.makeText(this@MainActivity, "Журнал пуст", Toast.LENGTH_SHORT).show()
            } else {
                pendingLogExport = content
                val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.getDefault()).format(Date())
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "ShiftHunter_log_$stamp.txt")
                }
                try {
                    startActivityForResult(intent, exportLogRequestCode)
                } catch (e: Exception) {
                    pendingLogExport = ""
                    Toast.makeText(this@MainActivity, "Не удалось открыть сохранение файла: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
        logs.addView(space(8))
        logs.addView(smallButton("Копировать журнал") {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("ShiftHunter log", LogStore.tail(this@MainActivity)))
            Toast.makeText(this@MainActivity, "Скопировано", Toast.LENGTH_SHORT).show()
        })
        logs.addView(space(7))
        logs.addView(smallButton("Очистить журнал", subtle = true) {
            LogStore.clear(this@MainActivity); refreshStatus()
        })
        logs.addView(space(7))
        logs.addView(smallButton("Сбросить историю записей", subtle = true) {
            PrefsLedgerStorage.clear(this@MainActivity)
            Toast.makeText(this@MainActivity, "История сброшена. Перезапусти службу (выкл/вкл в настройках Android)", Toast.LENGTH_LONG).show()
        })
        page.addView(logs)
        page.addView(space(20))
        page.addView(text("SHIFT HUNTER  •  НАСТРОЙКИ СОХРАНЯЮТСЯ НА УСТРОЙСТВЕ", 10f, muted, true).apply { gravity = Gravity.CENTER })
        setContentView(scroll)
    }

    @Deprecated("Используется для совместимости с ACTION_CREATE_DOCUMENT")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != exportLogRequestCode) return
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingLogExport = ""
            return
        }
        val content = pendingLogExport
        pendingLogExport = ""
        try {
            contentResolver.openOutputStream(data.data!!)?.use { stream ->
                stream.write(content.toByteArray(Charsets.UTF_8))
                stream.flush()
            } ?: throw IllegalStateException("Не удалось открыть файл для записи")
            Toast.makeText(this, "Журнал сохранён в TXT", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка сохранения журнала: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun regionField(parent: LinearLayout): AutoCompleteTextView {
        parent.addView(text("РЕГИОН", 11f, muted, true))
        parent.addView(space(6))
        val input = AutoCompleteTextView(this).apply {
            hint = "Начни вводить название региона"
            setSingleLine(true)
            threshold = 1
            textSize = 14f
            setTextColor(white)
            setHintTextColor(Color.rgb(112, 127, 153))
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(surface2, 14, stroke)
            setDropDownBackgroundDrawable(rounded(surface2, 12, stroke))
            dropDownHeight = dp(280)
            setText(prefs.getString("region", "") ?: "", false)
            setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, regions).also {
                it.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line)
            })
        }
        parent.addView(input, matchWrap(52))
        parent.addView(space(13))
        return input
    }

    private fun field(parent: LinearLayout, caption: String, hintText: String, key: String, learned: List<String>): AutoCompleteTextView {
        parent.addView(text(caption, 11f, muted, true))
        parent.addView(space(6))
        val input = AutoCompleteTextView(this).apply {
            hint = hintText
            setSingleLine(true)
            threshold = 1
            textSize = 14f
            setTextColor(white)
            setHintTextColor(Color.rgb(112, 127, 153))
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(surface2, 14, stroke)
            setDropDownBackgroundDrawable(rounded(surface2, 12, stroke))
            setText(prefs.getString(key, ""), false)
            setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, learned.distinct()))
        }
        parent.addView(input, matchWrap(52))
        parent.addView(space(13))
        return input
    }

    private fun toggleRow(parent: LinearLayout, icon: String, title: String, subtitle: String, key: String, default: Boolean, accent: Int): CheckBox {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
        row.addView(TextView(this).apply {
            text = icon; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(accent); background = rounded(surface2, 12)
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        labels.addView(text(title, 14f, white, true))
        labels.addView(text(subtitle, 12f, muted))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        val check = CheckBox(this).apply {
            buttonTintList = android.content.res.ColorStateList.valueOf(blue)
            isChecked = prefs.getBoolean(key, default)
        }
        row.addView(check)
        parent.addView(row)
        return check
    }

    private fun switchRow(parent: LinearLayout, title: String, subtitle: String, key: String, default: Boolean): CheckBox {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, dp(9)) }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(title, 14f, white, true))
        labels.addView(space(3))
        labels.addView(text(subtitle, 11f, muted))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        val check = CheckBox(this).apply {
            buttonTintList = android.content.res.ColorStateList.valueOf(blue)
            isChecked = prefs.getBoolean(key, default)
        }
        row.addView(check)
        parent.addView(row)
        return check
    }

    private fun weekdayRow(day: DayOfWeek, titleText: String, selectedMode: String): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(text(titleText, 14f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(pill(if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) "ВЫХОДНОЙ" else "БУДНИ", surface2, muted))
        container.addView(head)
        val choices = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            setPadding(0, dp(5), 0, 0)
        }
        val modes = listOf(
            "Автозапись" to BookingPolicy.MODE_AUTO,
            "Уведомление" to BookingPolicy.MODE_NOTIFY,
            "Выкл." to BookingPolicy.MODE_DISABLED
        )
        modes.forEach { (label, mode) ->
            val id = View.generateViewId()
            choices.addView(RadioButton(this).apply {
                this.id = id
                text = label
                textSize = 11f
                setTextColor(if (selectedMode == mode) Color.rgb(151, 194, 255) else muted)
                buttonTintList = android.content.res.ColorStateList.valueOf(blue)
                isChecked = selectedMode == mode
                setPadding(0, 0, dp(4), 0)
                tag = mode
            }, RadioGroup.LayoutParams(0, dp(42), 1f))
        }
        choices.setOnCheckedChangeListener { group, checkedId ->
            val selected = group.findViewById<RadioButton>(checkedId)
            weekdayModes[day] = selected?.tag as? String ?: BookingPolicy.MODE_NOTIFY
        }
        container.addView(choices)
        return container
    }

    private fun priorityRow(icon: String, title: String, subtitle: String, color: Int): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        row.addView(text(icon, 21f, color, true))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        labels.addView(text(title, 14f, white, true))
        labels.addView(text(subtitle, 11f, muted))
        row.addView(labels)
        return row
    }

    private fun sectionHeader(parent: LinearLayout, number: String, title: String, subtitle: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply {
            text = number; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.rgb(151, 194, 255))
            background = rounded(Color.rgb(25, 47, 78), 10)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        labels.addView(text(title, 17f, white, true))
        labels.addView(text(subtitle, 11f, muted))
        row.addView(labels)
        parent.addView(row)
        parent.addView(space(10))
    }

    private fun card(radius: Int = 18): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(surface, radius, stroke)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun pill(value: String, color: Int, textColor: Int) = TextView(this).apply {
        text = value; textSize = 10f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(textColor); gravity = Gravity.CENTER
        setPadding(dp(10), dp(7), dp(10), dp(7))
        background = rounded(color, 30)
    }

    private fun smallButton(value: String, subtle: Boolean = false, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setTextColor(if (subtle) muted else Color.rgb(190, 213, 248))
        background = rounded(if (subtle) surface2 else Color.rgb(25, 48, 78), 12, stroke)
        setOnClickListener { action() }
    }

    private fun secondaryButton(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setTextColor(Color.rgb(197, 215, 243))
        background = rounded(surface2, 16, stroke)
        setOnClickListener { action() }
    }

    private fun divider() = View(this).apply {
        setBackgroundColor(stroke)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(4); bottomMargin = dp(4) }
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchWrap(height: Int) = LinearLayout.LayoutParams(-1, dp(height))
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, border: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (border != null) setStroke(dp(1), border)
    }
}
