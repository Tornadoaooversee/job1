package ru.pythonlab.ozonshifthunter.core

import java.time.LocalDate

/** Что машина просит сделать сервис. Сама машина ничего не нажимает. */
sealed class Output {
    data class Log(val message: String) : Output()
    data class Notify(val title: String, val text: String, val dedupeId: String) : Output()
    /** Нажать узел. Сервис обязан заново найти узел по [UiNode.path] и сверить текст перед нажатием. */
    data class Click(val node: UiNode, val purpose: String, val screenSignature: String) : Output()
    class Back : Output()
}

typealias ColorProbe = (Bounds) -> ColorAnalysis

val NO_COLOR: ColorProbe = { ColorAnalysis(Priority.UNKNOWN, null, 0.0) }

/**
 * State machine распознавания экранов и (в активном режиме) безопасного прохода по календарю.
 *
 * Принципы:
 *  - dryRun=true (по умолчанию) → ни одного Click/Back, только лог и уведомления;
 *  - любой клик «Записаться» проходит финальные ворота [finalGate]: политика, журнал, проверка галочки,
 *    проверка даты, кнопка включена; состояние ATTEMPTED пишется в журнал ДО клика;
 *  - если что-то нельзя проверить (дата, галочка, контекст) — действие отменяется, а не угадывается;
 *  - после клика «Записаться» повторных кликов нет вообще: либо подтверждение, либо ошибка, либо UNCERTAIN.
 */
class HunterMachine(
    private val settings: () -> HunterSettings,
    private val ledger: BookingLedger,
    private val clock: () -> Long,
    private val today: () -> LocalDate
) {
    enum class Phase { IDLE, DAY_CLICKED, TIME_BTN_CLICKED, INTERVAL_CLICKED, BOOK_CLICKED, BACK_PRESSED }

    var phase: Phase = Phase.IDLE
        private set

    private var phaseSince = 0L
    private var lastType: ScreenType? = null
    private var lastClickAt = Long.MIN_VALUE / 2
    private var passDoneAt: Long? = null
    private val visited = HashSet<LocalDate>()
    private var clicksInPass = 0

    private var targetDate: LocalDate? = null
    private var targetInterval: ShiftInterval? = null
    private var lockedPriority: Priority = Priority.UNKNOWN
    private var bookKey: ShiftKey? = null
    /** Склад и операция были видны на экране календаря в момент старта прохода. */
    private var flowContextOk = false
    /** Контекст, подтверждённый на календаре. Настройки нельзя незаметно сменить посреди сценария. */
    private var flowRegion = ""
    private var flowWarehouse = ""
    private var flowOperation = ""

    private val knownDayPriority = HashMap<LocalDate, Priority>()
    private var lastSelected: Pair<LocalDate, Long>? = null
    private val lastLogByKey = HashMap<String, String>()

    fun reset() {
        phase = Phase.IDLE
        regionPairKey = null
        visited.clear()
        clicksInPass = 0
        passDoneAt = null
        targetDate = null; targetInterval = null; bookKey = null
        flowContextOk = false
        flowRegion = ""; flowWarehouse = ""; flowOperation = ""
        lockedPriority = Priority.UNKNOWN
    }

    /** Сервис не смог выполнить клик (узел не найден, текст не совпал, performAction вернул false). */
    fun onClickFailed(reason: String): List<Output> {
        val out = ArrayList<Output>()
        out += Output.Log("CLICK_FAILED phase=$phase: $reason")
        if (phase == Phase.BOOK_CLICKED) {
            // performAction(false) does not prove that the remote booking was not submitted.
            // Keep the attempt locked until a human verifies the result.
            bookKey?.let { ledger.markUncertain(it) }
            out += Output.Notify("Проверьте запись вручную", "Результат нажатия «Записаться» неясен: $reason. Повтор запрещён.", "unc-${bookKey?.id()}")
            endFlow(out, "результат клика «Записаться» неизвестен")
        } else if (phase != Phase.IDLE) {
            abort(out, "клик не выполнен: $reason")
        }
        return out
    }

    fun onSnapshot(snap: ScreenSnapshot, probe: ColorProbe = NO_COLOR): List<Output> {
        val out = ArrayList<Output>()
        val now = clock()
        val t = today()
        val s = settings()
        ledger.prune(t)

        val type = ScreenParser.classify(snap)
        if (type != lastType) {
            out += Output.Log("SCREEN type=$type pkg=${snap.packageName} nodes=${snap.nodes.size}${if (snap.truncated) " (усечено)" else ""}")
            lastType = type
        }
        if (type == ScreenType.NOT_OZON) {
            if (phase != Phase.IDLE) abort(out, "покинули Ozon Job")
            regionPairKey = null // ушли из Ozon Job: путь к складу нужно пройти заново
            return out
        }
        observeRegionPair(out, snap, s)

        if (phase != Phase.IDLE && now - phaseSince > timeoutFor(phase)) onTimeout(out, now)

        if (s.dryRun && phase != Phase.IDLE) abort(out, "включён режим наблюдения")
        if (phase != Phase.IDLE && flowContextOk && !flowSettingsMatch(s)) {
            abort(out, "регион, склад или операция изменились во время сценария; требуется новый проход")
        }

        // Календарь парсим один раз: он нужен и для наблюдения, и для проверки выбранной даты.
        val cal = if (type == ScreenType.CALENDAR || type == ScreenType.TIME_PICKER) ScreenParser.parseCalendar(snap, t) else null
        val picker = if (type == ScreenType.TIME_PICKER) ScreenParser.parsePicker(snap) else null
        if (cal != null) observeCalendar(out, snap, cal, probe, now, record = type == ScreenType.CALENDAR)

        when (phase) {
            Phase.IDLE -> when (type) {
                ScreenType.CALENDAR -> if (cal != null) idleCalendar(out, snap, cal, s, t, now)
                ScreenType.TIME_PICKER -> if (picker != null) {
                    val date = recentSelectedDate(now)
                    handlePicker(out, snap, picker, cal, date, ourFlow = false, s, t, now)
                }
                else -> Unit
            }

            Phase.DAY_CLICKED -> dayClicked(out, snap, type, cal, picker, s, t, now)

            Phase.TIME_BTN_CLICKED -> if (type == ScreenType.TIME_PICKER && picker != null) {
                handlePicker(out, snap, picker, cal, targetDate, ourFlow = true, s, t, now)
            }

            Phase.INTERVAL_CLICKED -> if (type == ScreenType.TIME_PICKER && picker != null) {
                intervalClicked(out, snap, picker, cal, s, t, now)
            }

            Phase.BOOK_CLICKED -> bookClicked(out, snap, now)

            Phase.BACK_PRESSED -> if (type == ScreenType.CALENDAR && picker == null) {
                phase = Phase.IDLE
                if (cal != null) idleCalendar(out, snap, cal, s, t, now)
            }
        }
        return out
    }

    // ------------------------------------------------------------------ календарь

    /** Ключ «регион|склад» из настроек, для которого уже видели склад рядом с текстом региона. */
    private var regionPairKey: String? = null

    private fun pairKeyOf(s: HunterSettings) = normalize(s.region) + "|" + normalize(s.warehouse)

    private fun observeRegionPair(out: MutableList<Output>, snap: ScreenSnapshot, s: HunterSettings) {
        if (!ScreenParser.regionWarehousePairVisible(snap, s)) return
        val key = pairKeyOf(s)
        if (regionPairKey != key) {
            regionPairKey = key
            out += Output.Log("REGION подтверждён по пути: склад «${s.warehouse}» виден рядом с регионом «${s.region}»")
        }
    }

    private fun observeCalendar(out: MutableList<Output>, snap: ScreenSnapshot, cal: CalendarInfo, probe: ColorProbe, now: Long, record: Boolean) {
        // Дата для окна времени известна только при ровно одном выбранном дне: Ozon Job разрешает выбрать
        // несколько дней сразу, и тогда окно времени относится к неизвестному набору дат.
        val selectedDays = cal.selectedDays
        if (selectedDays.size == 1) lastSelected = selectedDays[0].date to now
        else if (selectedDays.size > 1) lastSelected = null
        // Под окном выбора времени календарь затемнён — цвета с него не снимаем.
        if (!record) return
        val sb = StringBuilder()
        for (d in cal.days) {
            val (prio, hex) = dayPriority(snap, d, probe)
            // Цвет выбранного дня может быть перекрашен выделением — по пикселям запоминаем только невыбранные.
            // Признак из дерева (иконки) выделением не искажается, ему можно верить и у выбранного дня.
            if ((!d.selected || hex == TREE_SOURCE) && prio != Priority.UNKNOWN) knownDayPriority[d.date] = prio
            sb.append(d.date.dayOfMonth).append(prio.icon).append(if (d.selected) "*" else "")
            val icons = ScreenParser.iconNames((snap.descendants((d.clickTarget ?: d.node).index)).map { it.viewId })
            if (icons.isNotEmpty()) sb.append('[').append(icons.joinToString("+")).append(']')
            sb.append(' ')
            if (hex != "-") sb.append('(').append(hex).append(") ")
        }
        logChanged(out, "cal", "CALENDAR ${cal.month} days=${cal.days.size} selected=${cal.selectedDay?.date ?: "нет"} " +
            "timeButton=${cal.timeButton != null} :: $sb")
    }

    private fun dayPriority(snap: ScreenSnapshot, d: CalendarDay, probe: ColorProbe): Pair<Priority, String> {
        val cell = d.clickTarget ?: d.node
        val labels = (snap.descendants(cell.index) + cell).map { it.label }
        val byText = ScreenParser.priorityFromText(*labels.toTypedArray())
        if (byText != Priority.UNKNOWN) return byText to "text"

        // Дерево Ozon Job (лог 14.11) выдаёт и тип ячейки (HireContainer[name=…]), и иконки (HireIcon[name=…]).
        // Это надёжнее пикселей: огонёк → RED; ячейка без индикаторов → WHITE; полосы → GREEN/YELLOW (гипотеза).
        val ids = (snap.descendants(cell.index) + cell).map { it.viewId }
        var greenByIcon = false
        if (d.clickTarget != null && cell.enabled && d.node.enabled) {
            when (val byIcon = ScreenParser.priorityFromIcons(ids)) {
                Priority.RED, Priority.YELLOW -> return byIcon to TREE_SOURCE
                Priority.GREEN -> greenByIcon = true
                else -> if (ScreenParser.isPlainShiftCell(cell.viewId, ids)) return Priority.WHITE to TREE_SOURCE
            }
        }

        // Иначе (например, у выбранного дня или при неизвестной иконке) — пиксели области индикатора.
        // Пробовать всю карточку нельзя: фон/выделение дают ложный цвет.
        val b = cell.bounds
        if (d.clickTarget == null || b.width < 12 || b.height < 12 || !cell.enabled || !d.node.enabled) {
            return Priority.UNKNOWN to "inactive-or-small"
        }
        // Точная область иконок берётся из дерева (HireContainer[name=day_icon]); запасной вариант — угол ячейки.
        val iconBounds = snap.descendants(cell.index)
            .firstOrNull { it.viewId.contains("name=day_icon") && !it.bounds.isEmpty }?.bounds
        val indicator = iconBounds ?: Bounds(
            b.left + b.width * 58 / 100,
            b.top,
            b.right,
            b.top + b.height * 38 / 100
        )
        val a = probe(indicator)
        // Активная кликабельная дата без хроматического индикатора — WHITE.
        // Если снимок недоступен или в области есть неизвестный насыщенный цвет, остаётся UNKNOWN.
        val resolved = ColorClassifier.classifyIndicator(a, activeDay = true)
        if (greenByIcon) {
            // Иконка говорит «зелёная»; пиксели могут только опровергнуть (явно красный/жёлтый), но не подтвердить.
            val p = if (resolved == Priority.RED || resolved == Priority.YELLOW) Priority.UNKNOWN else Priority.GREEN
            return p to a.hex()
        }
        return resolved to a.hex()
    }

    private fun idleCalendar(out: MutableList<Output>, snap: ScreenSnapshot, cal: CalendarInfo, s: HunterSettings, t: LocalDate, now: Long) {
        if (s.dryRun) return
        // Регион на календаре не виден; его подтверждает путь «Склады → регион → склад → Записаться»:
        // на экране списка складов склад из настроек стоит рядом с текстом региона (см. observeRegionPair).
        val regionViaPath = regionPairKey == pairKeyOf(s) && ScreenParser.contextConfirmedWithoutRegion(snap, s)
        if (!ScreenParser.contextConfirmed(snap, s) && !regionViaPath) {
            logChanged(out, "ctx", "CONTEXT не подтверждён (на экране не найдено: ${ScreenParser.contextMissing(snap, s).joinToString()}): " +
                "регион «${s.region}», склад «${s.warehouse}», операция «${s.operation}» — только наблюдение. " +
                "Откройте календарь через «Склады» → регион → склад → «Записаться», чтобы подтвердить регион")
            return
        }
        passDoneAt?.let { if (now - it < PASS_COOLDOWN_MS) return }

        if (clicksInPass >= MAX_CLICKS_PER_PASS || visited.size >= MAX_DAYS_PER_PASS) {
            finishPass(out, now, "лимит прохода")
            return
        }
        val eligible = cal.days
            .filter { it.date >= t && it.clickTarget != null && it.node.enabled && it.clickTarget.enabled && it.date !in visited && !it.date.isAfter(t.plusDays(MAX_DAYS_AHEAD)) }
            .map { it to (knownDayPriority[it.date] ?: Priority.UNKNOWN) }
            .filter { it.second != Priority.YELLOW && it.second != Priority.UNKNOWN }
            // Дни недели, отключённые пользователем, политика всё равно отбросит (Ignore) — не открываем их.
            // Не-красные дни при «только горящие» открываем сознательно: ради уведомления о них.
            .filter { s.modeFor(it.first.date) != WeekdayMode.DISABLED }
            .sortedWith(compareBy({ it.second.rank }, { it.first.date }))
        if (eligible.isEmpty()) {
            if (visited.isNotEmpty()) finishPass(out, now, "все подходящие дни просмотрены")
            return
        }
        if (!canClick(now)) return
        val (day, prio) = eligible.first()
        visited += day.date
        targetDate = day.date
        lockedPriority = prio
        flowContextOk = true
        flowRegion = normalize(s.region)
        flowWarehouse = normalize(s.warehouse)
        flowOperation = normalize(s.operation)
        phase = Phase.DAY_CLICKED
        phaseSince = now
        click(out, day.clickTarget!!, "DAY ${day.date} prio=$prio", snap, now)
    }

    private fun finishPass(out: MutableList<Output>, now: Long, why: String) {
        out += Output.Log("PASS завершён ($why): дней=${visited.size}, кликов=$clicksInPass; следующий проход через ${PASS_COOLDOWN_MS / 1000} с")
        visited.clear()
        clicksInPass = 0
        passDoneAt = now
    }

    private fun dayClicked(
        out: MutableList<Output>, snap: ScreenSnapshot, type: ScreenType, cal: CalendarInfo?,
        picker: PickerInfo?, s: HunterSettings, t: LocalDate, now: Long
    ) {
        val target = targetDate ?: return abort(out, "нет целевой даты")
        if (type == ScreenType.TIME_PICKER && picker != null) {
            // Клик по дню сразу открыл выбор времени.
            phase = Phase.TIME_BTN_CLICKED
            handlePicker(out, snap, picker, cal, target, ourFlow = true, s, t, now)
            return
        }
        if (type != ScreenType.CALENDAR || cal == null) return
        if (cal.selectedDays.size > 1) {
            return abort(out, "выбрано несколько дней (${cal.selectedDays.map { it.date.dayOfMonth }}); автозапись возможна только для одного")
        }
        val sel = cal.selectedDay
        if (sel == null) {
            if (now - phaseSince > SELECTION_GRACE_MS) {
                abort(out, "SELECTION_UNVERIFIABLE: после клика по $target ни один день не помечен выбранным " +
                    "(selected/checked/«выбран» в дереве нет). Автопрогон невозможен — пришлите лог")
            }
            return
        }
        if (sel.date != target) {
            // Выделение может переехать со старого дня на новый не мгновенно.
            if (now - phaseSince > SELECTION_GRACE_MS) abort(out, "выбран день ${sel.date}, а нужен $target")
            return
        }
        val button = cal.timeButton ?: return // кнопка может появиться чуть позже
        val bt = snap.clickTarget(button) ?: button
        if (!canClick(now)) return
        phase = Phase.TIME_BTN_CLICKED
        phaseSince = now
        click(out, bt, "TIME_BUTTON $target", snap, now)
    }

    // ------------------------------------------------------------------ выбор времени

    private fun handlePicker(
        out: MutableList<Output>, snap: ScreenSnapshot, picker: PickerInfo, cal: CalendarInfo?,
        date: LocalDate?, ourFlow: Boolean, s: HunterSettings, t: LocalDate, now: Long
    ) {
        if (picker.otherIntervals.isNotEmpty()) {
            logChanged(out, "otherint", "PICKER нестандартные интервалы (игнорируются): ${picker.otherIntervals}")
        }
        if (date == null) {
            logChanged(out, "nodate", "PICKER ${picker.options.map { it.interval.label }}: дата неизвестна — решений не принимаю")
            return
        }
        // Проверка даты по календарю, если он виден под окном выбора времени.
        val sel = cal?.selectedDay
        if (ourFlow && sel != null && sel.date != date) return abort(out, "в календаре выбран ${sel.date}, а ожидался $date")

        class Row(val opt: IntervalOption, val cand: ShiftCandidate, val key: ShiftKey, val decision: Decision)

        val rows = picker.options.map { opt ->
            val prio = if (opt.textPriority != Priority.UNKNOWN) opt.textPriority else (knownDayPriority[date] ?: Priority.UNKNOWN)
            val cand = ShiftCandidate(date, opt.interval, prio)
            val key = ShiftKey(date, opt.interval, s.warehouse, s.operation)
            var d = PolicyEngine.evaluate(s, cand, t)
            if (d is Decision.AutoBook && ledger.hasActiveBookingOn(date)) d = Decision.NotifyOnly("на эту дату уже есть запись")
            Row(opt, cand, key, d)
        }
        for (r in rows) {
            logChanged(out, "pick-${r.key.id()}",
                "PICKER ${describe(r.cand)} checked=${r.opt.checked} enabled=${r.opt.enabled} toggle=${r.opt.toggle != null} → ${r.decision::class.simpleName}: ${r.decision.reason}")
        }

        val attemptable = if (ourFlow && !s.dryRun) {
            rows.filter { it.decision is Decision.AutoBook && ledger.canAttempt(it.key) }
                .sortedWith(compareBy({ it.cand.priority.rank }, { it.cand.interval.ordinal }))
                .firstOrNull()
        } else null

        // Уведомляем обо всём, кроме смены, которую сейчас будем бронировать (о ней скажет итог).
        for (r in rows) {
            if (r === attemptable) continue
            if (r.decision is Decision.Ignore) continue
            if (ledger.canNotify(r.key)) {
                val tail = when (r.decision) {
                    is Decision.AutoBook -> "автозапись возможна, но ${if (!ourFlow) "экран открыт не сканером" else "включён режим наблюдения"}"
                    else -> r.decision.reason
                }
                out += Output.Notify("Смена ${r.cand.priority.icon}", "${describe(r.cand)} · $tail", r.key.id())
                ledger.markNotified(r.key)
            }
        }

        if (!ourFlow) return

        if (attemptable == null) {
            finishDay(out, now, "нечего бронировать")
            return
        }
        val opt = attemptable.opt
        targetInterval = opt.interval
        lockedPriority = attemptable.cand.priority
        val toggle = opt.toggle
        if (toggle == null || !opt.enabled) return finishDay(out, now, "для ${opt.interval.label} нет доступного элемента выбора")
        when (opt.checked) {
            null -> abort(out, "состояние галочки ${opt.interval.label} не читается — запись отменена")
            true -> finalGate(out, snap, picker, cal, s, t, now)
            false -> {
                if (!canClick(now)) return
                phase = Phase.INTERVAL_CLICKED
                phaseSince = now
                click(out, toggle, "INTERVAL ${opt.interval.label} ${attemptable.key}", snap, now)
            }
        }
    }

    private fun intervalClicked(out: MutableList<Output>, snap: ScreenSnapshot, picker: PickerInfo, cal: CalendarInfo?, s: HunterSettings, t: LocalDate, now: Long) {
        val interval = targetInterval ?: return abort(out, "нет целевого интервала")
        val opt = picker.options.firstOrNull { it.interval == interval } ?: return
        if (opt.checked == true) finalGate(out, snap, picker, cal, s, t, now)
        // иначе ждём обновления интерфейса; по таймауту — отмена
    }

    /** Последняя проверка перед нажатием «Записаться». Любой провал = отмена без записи. */
    private fun finalGate(out: MutableList<Output>, snap: ScreenSnapshot, picker: PickerInfo, cal: CalendarInfo?, s: HunterSettings, t: LocalDate, now: Long) {
        val date = targetDate ?: return abort(out, "gate: нет даты")
        val interval = targetInterval ?: return abort(out, "gate: нет интервала")
        val key = ShiftKey(date, interval, s.warehouse, s.operation)
        fun no(why: String) = abort(out, "gate: $why")

        if (s.dryRun) return no("режим наблюдения")
        if (!flowContextOk) return no("контекст (склад/операция) не был подтверждён на календаре")
        val decision = PolicyEngine.evaluate(s, ShiftCandidate(date, interval, lockedPriority), t)
        if (decision !is Decision.AutoBook) return no("политика: ${decision.reason}")
        if (ledger.hasActiveBookingOn(date)) return no("на дату $date уже есть запись")
        if (!ledger.canAttempt(key)) return no("журнал запрещает повтор (${ledger.state(key)})")
        val sel = cal?.selectedDay
        if (sel != null && sel.date != date) return no("в календаре выбран ${sel.date}")
        val target = picker.options.firstOrNull { it.interval == interval } ?: return no("интервал пропал с экрана")
        if (target.checked != true) return no("интервал ${interval.label} не отмечен")
        val others = picker.options.filter { it.interval != interval }
        if (others.any { it.checked != false }) return no("отмечен или не читается другой интервал")
        val book = ScreenParser.bookClickTarget(snap, picker) ?: return no("кнопка «Записаться» не найдена")
        if (!book.enabled) return no("кнопка «Записаться» неактивна")
        if (!canClick(now)) return

        ledger.markAttempted(key) // ← ДО клика
        bookKey = key
        phase = Phase.BOOK_CLICKED
        phaseSince = now
        click(out, book, "BOOK $key prio=$lockedPriority", snap, now)
    }

    private fun bookClicked(out: MutableList<Output>, snap: ScreenSnapshot, now: Long) {
        val key = bookKey ?: return abort(out, "нет ключа записи")
        // Never accept a cached pre-click accessibility tree as proof of this attempt.
        // A newer tree alone is not enough to establish causality, but this prevents
        // one common false-positive and preserves UNCERTAIN on ambiguous outcomes.
        if (snap.timeMs <= phaseSince) return
        when (ScreenParser.detectResult(snap, key.date, key.interval)) {
            BookingResult.SUCCESS -> {
                ledger.markBooked(key)
                out += Output.Log("BOOKED $key — подтверждено текстом на экране")
                out += Output.Notify("✅ Записан на смену", "${describeKey(key)} — Ozon подтвердил запись", "booked-${key.id()}")
                endFlow(out, "готово")
            }
            BookingResult.WAITLISTED -> {
                ledger.markWaitlisted(key)
                out += Output.Log("WAITLISTED $key — заявка принята в очередь, НЕ подтверждена")
                out += Output.Notify("🕓 Заявка в очереди", "${describeKey(key)} — ждём решения Ozon; смена ещё не подтверждена", "wait-${key.id()}")
                endFlow(out, "постановка в очередь")
            }
            BookingResult.ERROR -> {
                ledger.markFailed(key)
                out += Output.Log("BOOK_ERROR $key — Ozon показал ошибку")
                out += Output.Notify("❌ Запись не удалась", "${describeKey(key)} — Ozon вернул ошибку", "err-${key.id()}")
                endFlow(out, "ошибка записи")
            }
            null -> Unit // ждём; по таймауту будет UNCERTAIN
        }
    }

    // ------------------------------------------------------------------ служебное

    private fun finishDay(out: MutableList<Output>, now: Long, why: String) {
        out += Output.Log("DAY_DONE $targetDate: $why → Назад")
        phase = Phase.BACK_PRESSED
        phaseSince = now
        if (canClick(now)) {
            lastClickAt = now
            clicksInPass++
            out += Output.Back()
        }
    }

    private fun onTimeout(out: MutableList<Output>, now: Long) {
        when (phase) {
            Phase.BOOK_CLICKED -> {
                val key = bookKey
                if (key != null) {
                    ledger.markUncertain(key)
                    out += Output.Notify("⚠ Проверьте запись вручную", "${describeKey(key)}: «Записаться» нажато, но подтверждения нет. Повторно не нажимаю.", "unc-${key.id()}")
                }
                endFlow(out, "таймаут подтверждения → UNCERTAIN")
            }
            else -> abort(out, "таймаут в фазе $phase")
        }
    }

    private fun timeoutFor(p: Phase): Long = when (p) {
        Phase.DAY_CLICKED, Phase.TIME_BTN_CLICKED -> 6_000
        Phase.INTERVAL_CLICKED -> 4_000
        Phase.BOOK_CLICKED -> 10_000
        Phase.BACK_PRESSED -> 4_000
        Phase.IDLE -> Long.MAX_VALUE
    }

    private fun abort(out: MutableList<Output>, why: String) {
        out += Output.Log("ABORT phase=$phase: $why")
        endFlow(out, why)
    }

    private fun endFlow(out: MutableList<Output>, why: String) {
        phase = Phase.IDLE
        targetDate = null; targetInterval = null; bookKey = null
        flowContextOk = false
        flowRegion = ""; flowWarehouse = ""; flowOperation = ""
        lockedPriority = Priority.UNKNOWN
        passDoneAt = clock() // пауза перед следующим проходом, чтобы не крутиться
        visited.clear(); clicksInPass = 0
    }

    private fun flowSettingsMatch(s: HunterSettings): Boolean =
        flowRegion == normalize(s.region) &&
            flowWarehouse == normalize(s.warehouse) &&
            flowOperation == normalize(s.operation)

    private fun canClick(now: Long) = now - lastClickAt >= MIN_CLICK_GAP_MS

    private fun click(out: MutableList<Output>, node: UiNode, purpose: String, snap: ScreenSnapshot, now: Long) {
        lastClickAt = now
        clicksInPass++
        out += Output.Log("ACTION click [$purpose] node=\"${node.label}\" id=${node.viewId} path=${node.path}")
        out += Output.Click(node, purpose, ScreenDump.signature(snap))
    }

    private fun recentSelectedDate(now: Long): LocalDate? =
        lastSelected?.takeIf { now - it.second <= SELECTED_TTL_MS }?.first

    private fun logChanged(out: MutableList<Output>, key: String, msg: String) {
        if (lastLogByKey[key] != msg) {
            lastLogByKey[key] = msg
            out += Output.Log(msg)
        }
    }

    companion object {
        /** Метка «приоритет определён по дереву Accessibility, а не по пикселям». */
        const val TREE_SOURCE = "tree"
        const val MIN_CLICK_GAP_MS = 700L
        const val PASS_COOLDOWN_MS = 45_000L
        const val SELECTION_GRACE_MS = 1_500L
        const val SELECTED_TTL_MS = 5 * 60_000L
        const val MAX_DAYS_PER_PASS = 14
        const val MAX_CLICKS_PER_PASS = 60
        const val MAX_DAYS_AHEAD = 45L

        private val DOW = listOf("пн", "вт", "ср", "чт", "пт", "сб", "вс")

        fun describeKey(k: ShiftKey): String = "${k.date.dayOfMonth}.${"%02d".format(k.date.monthValue)} (${DOW[k.date.dayOfWeek.value - 1]}) ${k.interval.label}"
        fun describe(c: ShiftCandidate): String = "${describeKey(ShiftKey(c.date, c.interval, "", ""))} ${c.priority.icon}"
    }
}
