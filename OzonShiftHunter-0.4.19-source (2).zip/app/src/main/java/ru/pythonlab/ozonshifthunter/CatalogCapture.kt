package ru.pythonlab.ozonshifthunter

import android.content.Context
import ru.pythonlab.ozonshifthunter.core.ScreenSnapshot
import java.util.Locale

/**
 * Локальное обучение справочников из видимого Accessibility-дерева Ozon Job.
 * Не обращается к сети, API, cookies или аккаунту. Сохраняет только короткие подписи
 * на экранах явного выбора региона/склада/операции.
 */
object CatalogCapture {
    private const val PREFS = "hunter_catalogs"
    private const val MAX_ITEMS = 150
    const val REGIONS = "regions"
    const val WAREHOUSES = "warehouses"
    const val OPERATIONS = "operations"

    data class Counts(val regions: Int, val warehouses: Int, val operations: Int)

    fun capture(context: Context, snapshot: ScreenSnapshot): Counts {
        if (snapshot.packageName != OzonNotificationPolicy.OZON_JOB_PACKAGE) return counts(context)
        val nodePairs = snapshot.nodes.map { it.label.trim() to it.viewId.lowercase(Locale.ROOT) }
            .filter { it.first.isNotBlank() }.distinctBy { it.first to it.second }
        val labels = nodePairs.map { it.first }
        val allText = (labels + snapshot.extraTexts).joinToString(" ").lowercase(Locale.ROOT)
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        var changed = false

        fun learn(key: String, candidates: List<String>) {
            if (candidates.isEmpty()) return
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val old = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            candidates.forEach { raw ->
                val value = raw.replace(Regex("\\s+"), " ").trim()
                if (isCandidate(value) && old.add(value)) changed = true
            }
            if (old.size > MAX_ITEMS) {
                val trimmed = old.toList().sorted().take(MAX_ITEMS).toSet()
                editor.putStringSet(key, trimmed)
            } else editor.putStringSet(key, old)
        }

        val regionScreen = hasAny(allText, "выберите регион", "выбор региона", "регионы", "регион") || nodePairs.any { it.second.contains("region") }
        val warehouseScreen = hasAny(allText, "выберите склад", "выбор склада", "склады", "склад", "объект") || nodePairs.any { it.second.contains("warehouse") || it.second.contains("object") }
        val operationScreen = hasAny(allText, "выберите операцию", "выбор операции", "операции", "процесс") || nodePairs.any { it.second.contains("operation") || it.second.contains("process") }

        if (regionScreen) learn(REGIONS, candidates(nodePairs, listOf("region", "area"), listOf("регион", "область", "край", "республика", "округ")))
        if (warehouseScreen) learn(WAREHOUSES, candidates(nodePairs, listOf("warehouse", "object", "facility"), listOf("склад", "рц", "рфц", "мц", "сц")))
        // Экран списка операций («ДОСТУПНЫЕ») не содержит слов «операция/процесс», поэтому узнаём его по карточкам:
        // название + цена «≈N ₽» + «Тариф». Названия берём напрямую.
        learn(OPERATIONS, ru.pythonlab.ozonshifthunter.core.ScreenParser.operationTitles(snapshot))
        if (operationScreen) learn(OPERATIONS, candidates(nodePairs, listOf("operation", "process", "position"), listOf("сортировка", "производство", "подбор", "приемка", "упаковка", "погрузка", "размещение", "возврат", "инвентаризация", "консолидация", "обработка")))

        if (changed) {
            editor.putLong("last_capture_ms", System.currentTimeMillis()).apply()
            LogStore.log(context, "CATALOG обновлён: регионы=${get(context, REGIONS).size}, склады=${get(context, WAREHOUSES).size}, операции=${get(context, OPERATIONS).size}; данные сохранены локально")
        }
        return counts(context)
    }

    private fun candidates(nodes: List<Pair<String, String>>, idHints: List<String>, textHints: List<String>): List<String> {
        return nodes.filter { (label, id) ->
            idHints.any { id.contains(it) } || textHints.any { label.contains(it, true) }
        }.map { it.first }
    }

    private fun isCandidate(value: String): Boolean {
        if (value.length !in 3..90) return false
        if (value.any { it.isDigit() }) return false
        val lower = value.lowercase(Locale.ROOT)
        val ignored = listOf("выберите", "выбрать", "поиск", "назад", "далее", "отмена", "готово", "сохранить", "фильтр", "регион", "склад", "операция", "процесс")
        if (ignored.any { lower == it || lower.startsWith("$it ") }) return false
        return value.count { it.isLetter() } >= 3
    }

    private fun hasAny(text: String, vararg terms: String) = terms.any { text.contains(it) }

    fun get(context: Context, key: String): List<String> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getStringSet(key, emptySet())?.toList()?.sorted() ?: emptyList()

    fun counts(context: Context) = Counts(get(context, REGIONS).size, get(context, WAREHOUSES).size, get(context, OPERATIONS).size)

    fun clear(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply() }
}
