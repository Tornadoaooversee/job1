package ru.pythonlab.ozonshifthunter

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationPolicyTests {
    @Test fun acceptsOnlyOzonJobNotifications() {
        assertTrue(OzonNotificationPolicy.shouldHandle("ru.ozon.hire", "ru.pythonlab.ozonshifthunter", false))
        assertFalse(OzonNotificationPolicy.shouldHandle("com.other.app", "ru.pythonlab.ozonshifthunter", false))
        assertFalse(OzonNotificationPolicy.shouldHandle(null, "ru.pythonlab.ozonshifthunter", false))
    }

    @Test fun rejectsOwnAndOngoingNotifications() {
        assertFalse(OzonNotificationPolicy.shouldHandle("ru.pythonlab.ozonshifthunter", "ru.pythonlab.ozonshifthunter", false))
        assertFalse(OzonNotificationPolicy.shouldHandle("ru.ozon.hire", "ru.pythonlab.ozonshifthunter", true))
    }

    @Test fun duplicateIsSuppressedOnlyInsideWindow() {
        assertTrue(OzonNotificationPolicy.isDuplicate("a", 1_000L, "a", 2_000L))
        assertFalse(OzonNotificationPolicy.isDuplicate("a", 1_000L, "b", 2_000L))
        assertFalse(OzonNotificationPolicy.isDuplicate("a", 1_000L, "a", 1_000L + OzonNotificationPolicy.DEDUPE_WINDOW_MS))
        assertFalse(OzonNotificationPolicy.isDuplicate("a", 2_000L, "a", 1_000L))
    }
}
