package ru.pythonlab.ozonshifthunter.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/**
 * Тесты на структуре, снятой с реального Ozon Job (лог ShiftHunter 14.11.2026):
 * ячейки дней — HireContainer[name=…], иконки — HireIcon[name=…], выбранный день — name=selectedDay.
 */
class RealTreeTests {
    private class Mem : LedgerStorage {
        var data = ""
        override fun load() = data
        override fun save(data: String) { this.data = data }
    }

    /** Описание ячейки дня: имя контейнера, кликабельность, иконки. */
    private class Cell(val kind: String, val clickable: Boolean, val icons: List<String> = emptyList())

    /** Календарь ноября 2026 (1 ноября — воскресенье) в той же структуре, что и в логе. */
    private fun calendar(cells: Map<Int, Cell>, timeMs: Long = 1_000L): ScreenSnapshot {
        val nodes = ArrayList<UiNode>()
        fun add(parent: Int, depth: Int, cls: String, text: String, viewId: String, clickable: Boolean, b: Bounds): Int {
            val idx = nodes.size
            nodes += UiNode(idx, parent, depth, emptyList(), cls, text, "", viewId, clickable, true, false, false, false, b)
            return idx
        }
        val root = add(-1, 0, "android.view.ViewGroup", "", "android:id/content", false, Bounds(0, 0, 1220, 2712))
        add(root, 1, "android.widget.TextView", "Ноябрь 2026", "HireText.Text", false, Bounds(48, 1011, 398, 1082))
        for (day in 1..30) {
            val pos = day - 1 + 6
            val left = 48 + (pos % 7) * 162
            val top = 1130 + (pos / 7) * 175
            val cell = cells[day] ?: Cell("unavailableShift", false)
            val c = add(root, 1, "android.view.View", "", "HireContainer[name=${cell.kind}]", cell.clickable, Bounds(left, top, left + 150, top + 150))
            add(c, 2, "android.widget.TextView", day.toString(), "", false, Bounds(left, top + 47, left + 150, top + 103))
            if (cell.icons.isNotEmpty()) {
                val box = add(c, 2, "android.view.View", "", "HireContainer[name=day_icon]", false, Bounds(left + 105, top, left + 150, top + 45))
                cell.icons.forEach { add(box, 3, "android.view.View", "", "HireIcon[name=$it]", false, Bounds(left + 105, top + 9, left + 141, top + 45)) }
            }
        }
        return ScreenSnapshot("ru.ozon.hire", nodes, timeMs)
    }

    private val today = LocalDate.of(2026, 11, 14)

    @Test fun selectedDayContainerMarksDaySelected() {
        val snap = calendar(mapOf(14 to Cell("selectedDay", true, listOf("ic_m_hot_filled")), 15 to Cell("queueShift", true)))
        val cal = ScreenParser.parseCalendar(snap, today)!!
        assertEquals(listOf(LocalDate.of(2026, 11, 14)), cal.selectedDays.map { it.date })
        assertEquals(LocalDate.of(2026, 11, 14), cal.selectedDay?.date)
    }

    @Test fun nothingSelectedWhenNoSelectedDayContainer() {
        val snap = calendar(mapOf(14 to Cell("availableShift", true), 15 to Cell("queueShift", true)))
        assertTrue(ScreenParser.parseCalendar(snap, today)!!.selectedDays.isEmpty())
    }

    @Test fun severalSelectedDaysAreReported() {
        val snap = calendar(mapOf(14 to Cell("selectedDay", true), 15 to Cell("selectedDay", true)))
        assertEquals(2, ScreenParser.parseCalendar(snap, today)!!.selectedDays.size)
    }

    @Test fun iconsMapToPriorities() {
        fun p(vararg n: String) = ScreenParser.priorityFromIcons(n.map { "HireIcon[name=$it]" })
        assertEquals(Priority.RED, p("ic_m_coins_stack_filled", "ic_m_hot_filled"))
        assertEquals(Priority.GREEN, p("ic_m_sort_small_large_filled_3"))
        assertEquals(Priority.YELLOW, p("ic_m_sort_small_large_filled_1"))
        assertEquals(Priority.YELLOW, p("ic_m_sort_small_large_filled_2"))
        assertEquals(Priority.UNKNOWN, p("ic_m_night_filled"))
        assertEquals(Priority.UNKNOWN, ScreenParser.priorityFromIcons(listOf("", "HireContainer[name=day_icon]")))
    }

    @Test fun plainShiftCellRules() {
        assertTrue(ScreenParser.isPlainShiftCell("HireContainer[name=availableShift]", listOf("", "")))
        assertTrue(ScreenParser.isPlainShiftCell("HireContainer[name=nightShift]", listOf("HireIcon[name=ic_m_night_filled]")))
        assertEquals(false, ScreenParser.isPlainShiftCell("HireContainer[name=queueShift]", listOf("HireIcon[name=ic_m_sort_small_large_filled_1]")))
        assertEquals(false, ScreenParser.isPlainShiftCell("HireContainer[name=unavailableShift]", emptyList()))
        assertEquals(false, ScreenParser.isPlainShiftCell("HireContainer[name=selectedDay]", emptyList()))
    }

    @Test fun machineLogsPrioritiesFromTreeWithoutScreenshot() {
        val snap = calendar(
            mapOf(
                14 to Cell("availableShift", true, listOf("ic_m_coins_stack_filled", "ic_m_hot_filled")),
                18 to Cell("availableShift", true),
                22 to Cell("availableShift", true, listOf("ic_m_sort_small_large_filled_3")),
                23 to Cell("queueShift", true, listOf("ic_m_sort_small_large_filled_1")),
                16 to Cell("queueShift", true, listOf("ic_m_sort_small_large_filled_1"))
            )
        )
        val machine = HunterMachine({ HunterSettings() }, BookingLedger(Mem()) { 0L }, { 1_000L }, { today })
        val log = machine.onSnapshot(snap).filterIsInstance<Output.Log>().map { it.message }.first { it.startsWith("CALENDAR") }
        assertTrue(log, "14🔴" in log)   // 🔴 горящая
        assertTrue(log, "18⚪" in log)         // ⚪ обычная
        assertTrue(log, "22🟢" in log)   // 🟢 три полосы
        assertTrue(log, "23🟡" in log)   // 🟡 одна полоса
        assertTrue(log, "1❔ " in log || "1❔(" in log) // ❔ недоступный день
    }

    private fun resultSheet(vararg labels: String): ScreenSnapshot {
        val nodes = ArrayList<UiNode>()
        nodes += UiNode(0, -1, 0, emptyList(), "android.view.ViewGroup", "", "", "android:id/content")
        labels.forEachIndexed { i, t -> nodes += UiNode(i + 1, 0, 1, listOf(i), "android.widget.TextView", t, "", "", bounds = Bounds(0, i * 10, 100, i * 10 + 9)) }
        return ScreenSnapshot("ru.ozon.hire", nodes, 5_000L)
    }

    private val queuedSheet = arrayOf("21 ноября", "Записи", "В очереди", "Отменить", "Омск РФЦ, 20:00–8:00", "Производство непрофиль", "Записаться ещё")

    @Test fun queuedResultSheetIsWaitlistedForMatchingDateAndInterval() {
        val s = resultSheet(*queuedSheet)
        assertEquals(BookingResult.WAITLISTED, ScreenParser.detectResult(s, LocalDate.of(2026, 11, 21), ShiftInterval.NIGHT))
    }

    @Test fun queuedResultSheetIgnoredForOtherDateOrInterval() {
        val s = resultSheet(*queuedSheet)
        assertNull(ScreenParser.detectResult(s, LocalDate.of(2026, 11, 22), ShiftInterval.NIGHT))
        assertNull(ScreenParser.detectResult(s, LocalDate.of(2026, 11, 21), ShiftInterval.DAY))
    }

    private val omsk = HunterSettings(region = "Омская Область", warehouse = "Омск РФЦ", operation = "Сортировка непрофиль")

    @Test fun warehouseMustMatchExactlyNotBySubstring() {
        val s = omsk.copy(warehouse = "Грозный Хаб", region = "Чеченская Республика")
        val longer = resultSheet("Чеченская Республика", "Грозный Хаб КГТ", "Сортировка непрофиль")
        assertEquals(false, ScreenParser.contextConfirmed(longer, s))
        assertEquals(false, ScreenParser.contextConfirmedWithoutRegion(longer, s))
        val exact = resultSheet("Чеченская Республика", "Грозный Хаб", "Сортировка непрофиль")
        assertTrue(ScreenParser.contextConfirmed(exact, s))
    }

    @Test fun calendarHeaderWithoutRegionIsConfirmedOnlyWithoutRegionRule() {
        val header = resultSheet("Омск РФЦ", "Сортировка непрофиль")
        assertEquals(false, ScreenParser.contextConfirmed(header, omsk))        // регион на календаре не виден
        assertTrue(ScreenParser.contextConfirmedWithoutRegion(header, omsk))    // склад и операция — точно
    }

    @Test fun warehouseListScreenGivesRegionEvidence() {
        val list = resultSheet("Омская Область", "5 объектов", "Омск РФЦ", "Россия, обл. Омская, г. Омск")
        assertTrue(ScreenParser.regionWarehousePairVisible(list, omsk))
        val otherRegion = resultSheet("Тульская Область", "Омск РФЦ")
        assertEquals(false, ScreenParser.regionWarehousePairVisible(otherRegion, omsk))
        val onlyWarehouse = resultSheet("Омск РФЦ")
        assertEquals(false, ScreenParser.regionWarehousePairVisible(onlyWarehouse, omsk))
    }

    @Test fun autoModeNeedsRegionPathBeforeCalendar() {
        val settings = omsk.copy(dryRun = false, autoEnabled = true)
        val cells = mapOf(14 to Cell("availableShift", true, listOf("ic_m_hot_filled")))
        fun calWithHeader(): ScreenSnapshot {
            val base = calendar(cells)
            val extra = listOf(
                UiNode(base.nodes.size, 0, 1, emptyList(), "android.widget.TextView", "Омск РФЦ", "", ""),
                UiNode(base.nodes.size + 1, 0, 1, emptyList(), "android.widget.TextView", "Сортировка непрофиль", "", "")
            )
            return ScreenSnapshot("ru.ozon.hire", base.nodes + extra, 2_000L)
        }
        fun newMachine() = HunterMachine({ settings }, BookingLedger(Mem()) { 0L }, { 2_000L }, { today })
        fun logs(o: List<Output>) = o.filterIsInstance<Output.Log>().map { it.message }
        fun clicked(o: List<Output>) = o.any { it is Output.Click }

        // без пути: календарь сам по себе не даёт клика
        val cold = newMachine().onSnapshot(calWithHeader())
        assertEquals(false, clicked(cold))
        assertTrue(logs(cold).any { it.startsWith("CONTEXT не подтверждён") })

        // сначала экран списка складов региона, затем календарь → день открывается
        val m = newMachine()
        val list = resultSheet("Омская Область", "5 объектов", "Омск РФЦ")
        assertTrue(logs(m.onSnapshot(list)).any { it.startsWith("REGION подтверждён") })
        val warm = m.onSnapshot(calWithHeader())
        assertTrue(logs(warm).toString(), clicked(warm))
    }

    @Test fun operationTitlesAreReadFromAvailableList() {
        val s = resultSheet(
            "ДОСТУПНЫЕ",
            "Размещение", "≈6 848 ₽", "Тариф", "Даты:", "Сегодня", "Завтра", "+29 дней",
            "Приемка", "≈6 474 ₽", "Тариф", "Даты:", "01.12", "02.12", "+12 дней",
            "Сортировка крупного товара", "≈6 517 ₽", "Тариф",
            "Подбор возвратов", "≈8 052 ₽", "Тариф",
            "Омск РФЦ", "≈8 694 ₽ / 12 ч", "≈724 ₽ / 1 ч"
        )
        assertEquals(
            listOf("Размещение", "Приемка", "Сортировка крупного товара", "Подбор возвратов"),
            ScreenParser.operationTitles(s)
        )
    }

    @Test fun operationTitlesSupportPriceBeforeTitleOrder() {
        val s = resultSheet("≈7 158 ₽", "Подбор", "Тариф")
        assertEquals(listOf("Подбор"), ScreenParser.operationTitles(s))
    }

    @Test fun knownOperationsMatchScreenshotList() {
        val shown = listOf(
            "Размещение", "Подбор", "Приемка", "Упаковка", "Сортировка крупного товара", "Возвраты",
            "Сортировка мелкого товара", "Консолидация", "Обработка проблемного товара", "Замена тары на автосортере",
            "Производство непрофиль", "Сортировка непрофиль", "Сортировка на автосортере", "Погрузка и разгрузка",
            "Инвентаризация", "Подбор возвратов"
        )
        assertEquals(shown.sorted(), KnownOperations.ALL.sorted())
    }

    @Test fun resultSheetIsNotClassifiedAsTimePicker() {
        assertEquals(ScreenType.UNKNOWN, ScreenParser.classify(resultSheet(*queuedSheet)))
    }
}
